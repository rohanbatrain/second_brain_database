"""LangChain specialized agents."""
