"""Voice agent integrating LangChain with LiveKit and voice processing."""
import asyncio
from typing import Dict, Any, Optional, AsyncIterator
from datetime import datetime, timezone
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.agents import AgentExecutor, create_tool_calling_agent

from ..orchestrator import LangChainOrchestrator
from ....integrations.voice_processor import voice_processor
from ....integrations.livekit import create_access_token
from ....managers.logging_manager import get_logger

logger = get_logger(prefix="[VoiceAgent]")


class VoiceAgent:
    """Voice-enabled AI agent with LiveKit integration."""
    
    def __init__(
        self,
        orchestrator: LangChainOrchestrator,
        livekit_url: str,
        livekit_api_key: str,
        livekit_api_secret: str,
    ):
        """Initialize voice agent.
        
        Args:
            orchestrator: LangChain orchestrator
            livekit_url: LiveKit server URL
            livekit_api_key: LiveKit API key
            livekit_api_secret: LiveKit API secret
        """
        self.orchestrator = orchestrator
        self.livekit_url = livekit_url
        self.livekit_api_key = livekit_api_key
        self.livekit_api_secret = livekit_api_secret
        self.active_sessions: Dict[str, Dict[str, Any]] = {}
    
    def create_livekit_token(
        self,
        identity: str,
        room: str,
        ttl: int = 3600,
    ) -> str:
        """Create LiveKit access token for voice session.
        
        Args:
            identity: User identity
            room: Room name
            ttl: Token TTL in seconds
            
        Returns:
            JWT token for LiveKit access
        """
        return create_access_token(
            api_key=self.livekit_api_key,
            api_secret=self.livekit_api_secret,
            identity=identity,
            room=room,
            ttl_seconds=ttl,
            can_publish=True,
            can_subscribe=True,
        )
    
    async def start_voice_session(
        self,
        user_id: str,
        session_id: str,
        room_name: Optional[str] = None,
    ) -> Dict[str, str]:
        """Start a voice AI session.
        
        Args:
            user_id: User ID
            session_id: Session ID
            room_name: Optional room name
            
        Returns:
            Session info with LiveKit token
        """
        if not room_name:
            room_name = f"voice-{session_id}"
        
        # Create LiveKit token
        token = self.create_livekit_token(
            identity=user_id,
            room=room_name,
        )
        
        # Store session
        self.active_sessions[session_id] = {
            "user_id": user_id,
            "room": room_name,
            "started_at": datetime.now(timezone.utc),
            "audio_buffer": [],
        }
        
        logger.info(f"Started voice session {session_id} for user {user_id}")
        
        return {
            "session_id": session_id,
            "room": room_name,
            "token": token,
            "livekit_url": self.livekit_url,
        }
    
    async def process_audio_stream(
        self,
        session_id: str,
        audio_data: bytes,
        sample_rate: int = 16000,
    ) -> AsyncIterator[bytes]:
        """Process incoming audio stream from LiveKit.
        
        Args:
            session_id: Session ID
            audio_data: Audio data bytes
            sample_rate: Sample rate
            
        Yields:
            Response audio chunks
        """
        if session_id not in self.active_sessions:
            raise ValueError(f"Session {session_id} not found")
        
        session = self.active_sessions[session_id]
        
        try:
            # Speech-to-text
            text = await voice_processor.speech_to_text(audio_data, sample_rate)
            
            if not text:
                logger.warning(f"No speech detected in session {session_id}")
                return
            
            logger.info(f"Transcribed: {text[:100]}...")
            
            # Get user context from session
            from ....integrations.mcp.context import MCPUserContext
            user_context = MCPUserContext(
                user_id=session["user_id"],
                username="",
                email="",
                role="user",
                permissions=[],
                family_memberships=[],
                workspaces=[],
                ip_address="",
                user_agent="voice-agent",
                token_type="livekit",
                token_id=session_id,
                authenticated_at=session["started_at"],
            )
            
            # Process with LangChain orchestrator
            response = await self.orchestrator.chat(
                session_id=session_id,
                user_id=session["user_id"],
                message=text,
                user_context=user_context,
                agent_type="general",
            )
            
            if "error" in response:
                logger.error(f"Orchestrator error: {response['error']}")
                error_audio = await voice_processor.text_to_speech(
                    "I encountered an error processing your request."
                )
                yield error_audio
                return
            
            # Text-to-speech
            response_text = response["response"]
            logger.info(f"Generating speech for: {response_text[:100]}...")
            
            # Stream TTS in chunks
            response_audio = await voice_processor.text_to_speech(response_text)
            
            # Chunk audio for streaming (16KB chunks)
            chunk_size = 16384
            for i in range(0, len(response_audio), chunk_size):
                yield response_audio[i:i + chunk_size]
        
        except Exception as e:
            logger.error(f"Voice processing error: {e}")
            error_audio = await voice_processor.text_to_speech(
                "Sorry, I couldn't process that."
            )
            yield error_audio
    
    async def end_voice_session(self, session_id: str):
        """End a voice session.
        
        Args:
            session_id: Session ID
        """
        if session_id in self.active_sessions:
            del self.active_sessions[session_id]
            
            # Clear orchestrator session
            self.orchestrator.clear_session(session_id)
            
            logger.info(f"Ended voice session {session_id}")
    
    def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get voice session info.
        
        Args:
            session_id: Session ID
            
        Returns:
            Session info or None
        """
        return self.active_sessions.get(session_id)
