"""Base LangChain tool wrapper for MCP tools."""
from typing import Any, Callable, Optional, Type, Dict
from pydantic import BaseModel, Field, create_model
from langchain_core.tools import StructuredTool
from langchain_core.callbacks import CallbackManagerForToolRun
from ....integrations.mcp.context import MCPUserContext


def create_langchain_tool_from_mcp(
    name: str,
    description: str,
    func: Callable,
    user_context: MCPUserContext,
    args_schema: Optional[Type[BaseModel]] = None,
) -> StructuredTool:
    """Create a LangChain StructuredTool from an MCP function.
    
    This properly wraps MCP tools (which expect user_context as first arg)
    into LangChain tools that can be used by agents.
    
    Args:
        name: Tool name
        description: Tool description
        func: The MCP tool function (async or sync)
        user_context: MCP user context to inject
        args_schema: Pydantic model for tool arguments
        
    Returns:
        LangChain StructuredTool instance
    """
    import asyncio
    import inspect
    
    # Determine if function is async
    is_async = inspect.iscoroutinefunction(func)
    
    # Create wrapper that injects user_context
    def sync_wrapper(**kwargs) -> Any:
        """Synchronous wrapper that injects user context."""
        try:
            if is_async:
                # Run async function in event loop
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    # If loop is running, create a task
                    import concurrent.futures
                    with concurrent.futures.ThreadPoolExecutor() as pool:
                        future = pool.submit(asyncio.run, func(user_context, **kwargs))
                        return future.result()
                else:
                    return loop.run_until_complete(func(user_context, **kwargs))
            else:
                return func(user_context, **kwargs)
        except Exception as e:
            return {"error": str(e)}
    
    async def async_wrapper(**kwargs) -> Any:
        """Async wrapper that injects user context."""
        try:
            if is_async:
                return await func(user_context, **kwargs)
            else:
                return func(user_context, **kwargs)
        except Exception as e:
            return {"error": str(e)}
    
    # Create default schema if not provided
    if args_schema is None:
        args_schema = create_model(
            f"{name}Args",
            __base__=BaseModel,
        )
    
    # Return LangChain StructuredTool
    return StructuredTool(
        name=name,
        description=description,
        func=sync_wrapper,
        coroutine=async_wrapper if is_async else None,
        args_schema=args_schema,
    )


# Deprecated - kept for backwards compatibility
class MCPToolWrapper:
    """Deprecated: Use create_langchain_tool_from_mcp instead."""
    pass


def create_mcp_tool_wrapper(*args, **kwargs):
    """Deprecated: Use create_langchain_tool_from_mcp instead."""
    return create_langchain_tool_from_mcp(*args, **kwargs)
