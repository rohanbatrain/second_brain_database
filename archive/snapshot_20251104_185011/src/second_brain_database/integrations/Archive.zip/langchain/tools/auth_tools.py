"""LangChain wrappers for authentication MCP tools."""
from typing import List
from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool
from .base import create_langchain_tool_from_mcp
from ....integrations.mcp.context import MCPUserContext
from ....integrations.mcp.tools import auth_tools as mcp_auth


class GetProfileInput(BaseModel):
    """Input for get_profile tool."""
    user_id: str = Field(description="User ID to get profile for")


class UpdateProfileInput(BaseModel):
    """Input for update_profile tool."""
    display_name: str = Field(default=None, description="Display name")
    bio: str = Field(default=None, description="User bio")
    avatar_url: str = Field(default=None, description="Avatar URL")


class Enable2FAInput(BaseModel):
    """Input for enable_2fa tool."""
    totp_secret: str = Field(description="TOTP secret")


class Verify2FAInput(BaseModel):
    """Input for verify_2fa tool."""
    totp_code: str = Field(description="6-digit TOTP code")


def get_func(mcp_tool):
    """Extract the underlying function from an MCP FunctionTool."""
    if hasattr(mcp_tool, 'fn'):
        return mcp_tool.fn
    elif hasattr(mcp_tool, '__call__'):
        return mcp_tool
    else:
        raise ValueError(f"Cannot extract function from {type(mcp_tool)}")


def create_auth_tools(user_context: MCPUserContext) -> List[StructuredTool]:
    """Create LangChain wrappers for auth MCP tools.
    
    Args:
        user_context: MCP user context
        
    Returns:
        List of auth tool wrappers
    """
    tools = []
    
    # Get Profile
    if hasattr(mcp_auth, 'get_user_profile'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_user_profile",
            description="Get user profile information",
            func=get_func(mcp_auth.get_user_profile),
            user_context=user_context,
        ))
    
    # Update Profile
    if hasattr(mcp_auth, 'update_user_profile'):
        tools.append(create_langchain_tool_from_mcp(
            name="update_user_profile",
            description="Update user profile information",
            func=get_func(mcp_auth.update_user_profile),
            user_context=user_context,
            args_schema=UpdateProfileInput,
        ))
    
    # Get Security Dashboard
    if hasattr(mcp_auth, 'get_security_dashboard'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_security_dashboard",
            description="Get comprehensive security status for the user",
            func=get_func(mcp_auth.get_security_dashboard),
            user_context=user_context,
        ))
    
    return tools
