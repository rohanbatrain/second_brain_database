"""LangChain wrappers for admin MCP tools."""
from typing import List, Optional
from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

from .base import create_langchain_tool_from_mcp
from ....integrations.mcp.context import MCPUserContext
from ....integrations.mcp.tools import admin_tools as mcp_admin


# Helper function to extract callable from FunctionTool
def get_func(mcp_tool):
    """Extract the underlying function from a FastMCP FunctionTool."""
    if hasattr(mcp_tool, 'fn'):
        return mcp_tool.fn
    elif hasattr(mcp_tool, '__call__'):
        return mcp_tool
    else:
        raise ValueError(f"Cannot extract function from {type(mcp_tool)}")


# Pydantic input schemas for admin tools

# System Monitoring Tools
class GetDatabaseStatsInput(BaseModel):
    """Input for get_database_stats tool."""
    pass  # No parameters needed


class GetRedisStatsInput(BaseModel):
    """Input for get_redis_stats tool."""
    pass  # No parameters needed


class GetAPIMetricsInput(BaseModel):
    """Input for get_api_metrics tool."""
    pass  # No parameters needed


class GetErrorLogsInput(BaseModel):
    """Input for get_error_logs tool."""
    limit: int = Field(default=50, description="Maximum number of log entries to return")
    level: Optional[str] = Field(default=None, description="Log level filter (ERROR, WARNING, CRITICAL)")
    since_hours: int = Field(default=24, description="Number of hours back to search")


class GetPerformanceMetricsInput(BaseModel):
    """Input for get_performance_metrics tool."""
    pass  # No parameters needed


# User Management Tools
class GetUserListInput(BaseModel):
    """Input for get_user_list tool."""
    limit: int = Field(default=50, description="Maximum number of users to return")
    offset: int = Field(default=0, description="Number of users to skip for pagination")
    search: Optional[str] = Field(default=None, description="Search term for username or email")
    role_filter: Optional[str] = Field(default=None, description="Filter by user role")
    status_filter: Optional[str] = Field(default=None, description="Filter by account status")


class GetUserDetailsInput(BaseModel):
    """Input for get_user_details tool."""
    user_id: str = Field(description="The ID of the user to get details for")


class SuspendUserInput(BaseModel):
    """Input for suspend_user tool."""
    user_id: str = Field(description="The ID of the user to suspend")
    reason: str = Field(description="Reason for suspension (required for audit trail)")
    duration_hours: Optional[int] = Field(default=None, description="Suspension duration in hours (permanent if not specified)")


class UnsuspendUserInput(BaseModel):
    """Input for unsuspend_user tool."""
    user_id: str = Field(description="The ID of the user to unsuspend")
    reason: str = Field(description="Reason for removing suspension")


class ResetUserPasswordInput(BaseModel):
    """Input for reset_user_password tool."""
    user_id: str = Field(description="The ID of the user to reset password for")
    notify_user: bool = Field(default=True, description="Whether to notify user via email")
    temporary_password: Optional[str] = Field(default=None, description="Temporary password (generated if not provided)")


class GetUserActivityLogInput(BaseModel):
    """Input for get_user_activity_log tool."""
    user_id: str = Field(description="The ID of the user to get activity for")
    limit: int = Field(default=50, description="Maximum number of activity entries to return")
    activity_type: Optional[str] = Field(default=None, description="Filter by activity type")
    since_hours: int = Field(default=168, description="Number of hours back to search (default: 1 week)")


class ModerateUserContentInput(BaseModel):
    """Input for moderate_user_content tool."""
    user_id: str = Field(description="The ID of the user whose content to moderate")
    content_type: str = Field(description="Type of content (profile, bio, avatar, banner, etc.)")
    action: str = Field(description="Moderation action (hide, remove, flag, approve)")
    reason: str = Field(description="Reason for moderation action")


# System Configuration Tools
class GetSystemConfigInput(BaseModel):
    """Input for get_system_config tool."""
    pass  # No parameters needed


class UpdateSystemSettingsInput(BaseModel):
    """Input for update_system_settings tool."""
    setting_key: str = Field(description="The setting key to update")
    setting_value: str = Field(description="The new value for the setting")
    reason: str = Field(description="Reason for changing the setting")


class GetFeatureFlagsInput(BaseModel):
    """Input for get_feature_flags tool."""
    pass  # No parameters needed


class ToggleFeatureFlagInput(BaseModel):
    """Input for toggle_feature_flag tool."""
    flag_name: str = Field(description="Name of the feature flag to toggle")
    enabled: bool = Field(description="Whether to enable or disable the feature")
    reason: str = Field(description="Reason for toggling the feature flag")


class GetMaintenanceStatusInput(BaseModel):
    """Input for get_maintenance_status tool."""
    pass  # No parameters needed


class ScheduleMaintenanceInput(BaseModel):
    """Input for schedule_maintenance tool."""
    start_time: str = Field(description="Start time of maintenance (ISO format)")
    duration_minutes: int = Field(description="Duration of maintenance in minutes")
    description: str = Field(description="Description of the maintenance")
    notify_users: bool = Field(default=True, description="Whether to notify users")


def create_admin_tools(user_context: MCPUserContext) -> List[StructuredTool]:
    """Create LangChain wrappers for admin MCP tools.
    
    This function creates StructuredTool instances for all admin-related
    MCP tools, enabling LangChain agents to perform system administration,
    monitoring, and user management tasks.
    
    Args:
        user_context: MCP user context containing authentication and permissions
        
    Returns:
        List of StructuredTool instances for admin operations
    """
    tools = []
    
    # System Monitoring Tools (Task 8.1)
    if hasattr(mcp_admin, 'get_system_health'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_system_health",
            description="Get comprehensive system health status including all components (admin only)",
            func=get_func(mcp_admin.get_system_health),
            user_context=user_context,
        ))
    
    if hasattr(mcp_admin, 'get_database_stats'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_database_stats",
            description="Get detailed database metrics and statistics (admin only)",
            func=get_func(mcp_admin.get_database_stats),
            user_context=user_context,
        ))
    
    if hasattr(mcp_admin, 'get_redis_stats'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_redis_stats",
            description="Get Redis cache metrics and performance statistics (admin only)",
            func=get_func(mcp_admin.get_redis_stats),
            user_context=user_context,
        ))
    
    if hasattr(mcp_admin, 'get_api_metrics'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_api_metrics",
            description="Get API performance metrics and request statistics (admin only)",
            func=get_func(mcp_admin.get_api_metrics),
            user_context=user_context,
        ))
    
    if hasattr(mcp_admin, 'get_error_logs'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_error_logs",
            description="Get recent error logs for system monitoring and debugging (admin only)",
            func=get_func(mcp_admin.get_error_logs),
            user_context=user_context,
            args_schema=GetErrorLogsInput,
        ))
    
    if hasattr(mcp_admin, 'get_performance_metrics'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_performance_metrics",
            description="Get comprehensive system performance metrics (admin only)",
            func=get_func(mcp_admin.get_performance_metrics),
            user_context=user_context,
        ))
    
    # User Management and Moderation Tools (Task 8.2)
    if hasattr(mcp_admin, 'get_user_list'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_user_list",
            description="Get paginated list of users for administration (admin only)",
            func=get_func(mcp_admin.get_user_list),
            user_context=user_context,
            args_schema=GetUserListInput,
        ))
    
    if hasattr(mcp_admin, 'get_user_details'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_user_details",
            description="Get detailed information about a specific user (admin only)",
            func=get_func(mcp_admin.get_user_details),
            user_context=user_context,
            args_schema=GetUserDetailsInput,
        ))
    
    if hasattr(mcp_admin, 'suspend_user'):
        tools.append(create_langchain_tool_from_mcp(
            name="suspend_user",
            description="Suspend a user account with specified reason and duration (admin only)",
            func=get_func(mcp_admin.suspend_user),
            user_context=user_context,
            args_schema=SuspendUserInput,
        ))
    
    if hasattr(mcp_admin, 'unsuspend_user'):
        tools.append(create_langchain_tool_from_mcp(
            name="unsuspend_user",
            description="Remove suspension from a user account (admin only)",
            func=get_func(mcp_admin.unsuspend_user),
            user_context=user_context,
            args_schema=UnsuspendUserInput,
        ))
    
    if hasattr(mcp_admin, 'reset_user_password'):
        tools.append(create_langchain_tool_from_mcp(
            name="reset_user_password",
            description="Reset a user's password for administrative purposes (admin only)",
            func=get_func(mcp_admin.reset_user_password),
            user_context=user_context,
            args_schema=ResetUserPasswordInput,
        ))
    
    if hasattr(mcp_admin, 'get_user_activity_log'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_user_activity_log",
            description="Get activity log for a specific user (admin only)",
            func=get_func(mcp_admin.get_user_activity_log),
            user_context=user_context,
            args_schema=GetUserActivityLogInput,
        ))
    
    if hasattr(mcp_admin, 'moderate_user_content'):
        tools.append(create_langchain_tool_from_mcp(
            name="moderate_user_content",
            description="Moderate user-generated content (admin only)",
            func=get_func(mcp_admin.moderate_user_content),
            user_context=user_context,
            args_schema=ModerateUserContentInput,
        ))
    
    # System Configuration Tools (Task 8.3)
    if hasattr(mcp_admin, 'get_system_config'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_system_config",
            description="Get current system configuration and settings (admin only)",
            func=get_func(mcp_admin.get_system_config),
            user_context=user_context,
        ))
    
    if hasattr(mcp_admin, 'update_system_settings'):
        tools.append(create_langchain_tool_from_mcp(
            name="update_system_settings",
            description="Update system settings and configuration (admin only)",
            func=get_func(mcp_admin.update_system_settings),
            user_context=user_context,
            args_schema=UpdateSystemSettingsInput,
        ))
    
    if hasattr(mcp_admin, 'get_feature_flags'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_feature_flags",
            description="Get all feature flags and their current states (admin only)",
            func=get_func(mcp_admin.get_feature_flags),
            user_context=user_context,
        ))
    
    if hasattr(mcp_admin, 'toggle_feature_flag'):
        tools.append(create_langchain_tool_from_mcp(
            name="toggle_feature_flag",
            description="Toggle a feature flag on or off (admin only)",
            func=get_func(mcp_admin.toggle_feature_flag),
            user_context=user_context,
            args_schema=ToggleFeatureFlagInput,
        ))
    
    if hasattr(mcp_admin, 'get_maintenance_status'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_maintenance_status",
            description="Get current maintenance status and scheduled maintenance (admin only)",
            func=get_func(mcp_admin.get_maintenance_status),
            user_context=user_context,
        ))
    
    if hasattr(mcp_admin, 'schedule_maintenance'):
        tools.append(create_langchain_tool_from_mcp(
            name="schedule_maintenance",
            description="Schedule system maintenance with user notification (admin only)",
            func=get_func(mcp_admin.schedule_maintenance),
            user_context=user_context,
            args_schema=ScheduleMaintenanceInput,
        ))
    
    return tools
