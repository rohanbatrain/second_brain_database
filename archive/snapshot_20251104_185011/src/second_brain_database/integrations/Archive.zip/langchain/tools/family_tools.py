"""LangChain wrappers for family MCP tools."""
from typing import List
from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool
from .base import create_langchain_tool_from_mcp
from ....integrations.mcp.context import MCPUserContext
from ....integrations.mcp.tools import family_tools as mcp_family


class CreateFamilyInput(BaseModel):
    """Input for create_family tool."""
    name: str = Field(description="Family name")
    description: str = Field(default="", description="Family description")


class InviteMemberInput(BaseModel):
    """Input for invite_member tool."""
    family_id: str = Field(description="Family ID")
    email: str = Field(description="Email of user to invite")
    role: str = Field(default="member", description="Role: admin or member")


class GetFamilyInput(BaseModel):
    """Input for get_family tool."""
    family_id: str = Field(description="Family ID")


def get_func(mcp_tool):
    """Extract the underlying function from an MCP FunctionTool."""
    if hasattr(mcp_tool, 'fn'):
        # FastMCP FunctionTool has .fn attribute
        return mcp_tool.fn
    elif hasattr(mcp_tool, '__call__'):
        return mcp_tool
    else:
        raise ValueError(f"Cannot extract function from {type(mcp_tool)}")


def create_family_tools(user_context: MCPUserContext) -> List[StructuredTool]:
    """Create LangChain tools from family MCP tools.
    
    Args:
        user_context: MCP user context with authentication
        
    Returns:
        List of LangChain StructuredTool instances for family operations
    """
    tools = []
    
    # Get Family Info
    if hasattr(mcp_family, 'get_family_info'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_family_info",
            description="Get detailed information about a specific family including members and account details",
            func=get_func(mcp_family.get_family_info),
            user_context=user_context,
            args_schema=GetFamilyInput,
        ))
    
    # List User Families
    if hasattr(mcp_family, 'list_user_families'):
        tools.append(create_langchain_tool_from_mcp(
            name="list_user_families",
            description="Get all families the current user belongs to",
            func=get_func(mcp_family.list_user_families),
            user_context=user_context,
        ))
    
    return tools
