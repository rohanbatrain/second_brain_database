"""LangChain wrappers for shop MCP tools."""
from typing import List
from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool
from .base import create_langchain_tool_from_mcp
from ....integrations.mcp.context import MCPUserContext
from ....integrations.mcp.tools import shop_tools as mcp_shop


class GetItemInput(BaseModel):
    """Input for get_item tool."""
    item_id: str = Field(description="Item ID")


class PurchaseItemInput(BaseModel):
    """Input for purchase_item tool."""
    item_id: str = Field(description="Item ID to purchase")
    quantity: int = Field(default=1, description="Quantity to purchase")


def get_func(mcp_tool):
    """Extract the underlying function from an MCP FunctionTool."""
    if hasattr(mcp_tool, 'fn'):
        # FastMCP FunctionTool has .fn attribute
        return mcp_tool.fn
    elif hasattr(mcp_tool, '__call__'):
        return mcp_tool
    else:
        raise ValueError(f"Cannot extract function from {type(mcp_tool)}")


def create_shop_tools(user_context: MCPUserContext) -> List[StructuredTool]:
    """Create LangChain tools from shop MCP tools.
    
    Args:
        user_context: MCP user context
        
    Returns:
        List of shop LangChain tools
    """
    tools = []
    
    # Get Featured Items
    if hasattr(mcp_shop, 'get_featured_items'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_featured_items",
            description="Get featured items currently available in the shop",
            func=get_func(mcp_shop.get_featured_items),
            user_context=user_context,
        ))
    
    # Get Owned Avatars
    if hasattr(mcp_shop, 'get_owned_avatars'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_owned_avatars",
            description="Get all avatars owned by the current user",
            func=get_func(mcp_shop.get_owned_avatars),
            user_context=user_context,
        ))
    
    return tools
