"""LangChain wrappers for workspace MCP tools."""
from typing import List, Optional
from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

from .base import create_langchain_tool_from_mcp
from ....integrations.mcp.context import MCPUserContext
from ....integrations.mcp.tools import workspace_tools as mcp_workspace


# Helper function to extract callable from FunctionTool
def get_func(mcp_tool):
    """Extract the underlying function from a FastMCP FunctionTool."""
    if hasattr(mcp_tool, 'fn'):
        return mcp_tool.fn
    elif hasattr(mcp_tool, '__call__'):
        return mcp_tool
    else:
        raise ValueError(f"Cannot extract function from {type(mcp_tool)}")


# Pydantic input schemas for workspace tools
class GetWorkspaceDetailsInput(BaseModel):
    """Input for get_workspace_details tool."""
    workspace_id: str = Field(description="The ID of the workspace to get details for")


class CreateWorkspaceInput(BaseModel):
    """Input for create_workspace tool."""
    name: str = Field(description="Name of the workspace")
    description: Optional[str] = Field(default=None, description="Description of the workspace")
    workspace_type: Optional[str] = Field(default="team", description="Type of workspace (team, project, department)")


class UpdateWorkspaceInput(BaseModel):
    """Input for update_workspace tool."""
    workspace_id: str = Field(description="The ID of the workspace to update")
    name: Optional[str] = Field(default=None, description="New name for the workspace")
    description: Optional[str] = Field(default=None, description="New description for the workspace")
    settings: Optional[dict] = Field(default=None, description="New workspace settings")


class DeleteWorkspaceInput(BaseModel):
    """Input for delete_workspace tool."""
    workspace_id: str = Field(description="The ID of the workspace to delete")
    confirm: bool = Field(default=False, description="Confirmation flag - must be true to delete")


class GetWorkspaceSettingsInput(BaseModel):
    """Input for get_workspace_settings tool."""
    workspace_id: str = Field(description="The ID of the workspace to get settings for")


class AddWorkspaceMemberInput(BaseModel):
    """Input for add_workspace_member tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    user_id: str = Field(description="The ID of the user to add")
    role: str = Field(default="viewer", description="Role to assign (admin, editor, viewer)")


class RemoveWorkspaceMemberInput(BaseModel):
    """Input for remove_workspace_member tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    user_id: str = Field(description="The ID of the user to remove")


class UpdateMemberRoleInput(BaseModel):
    """Input for update_member_role tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    user_id: str = Field(description="The ID of the user to update")
    new_role: str = Field(description="New role to assign (admin, editor, viewer)")


class GetWorkspaceMembersInput(BaseModel):
    """Input for get_workspace_members tool."""
    workspace_id: str = Field(description="The ID of the workspace to get members for")


class InviteWorkspaceMemberInput(BaseModel):
    """Input for invite_workspace_member tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    email: str = Field(description="Email address of the user to invite")
    role: str = Field(default="viewer", description="Role to assign (admin, editor, viewer)")
    message: Optional[str] = Field(default=None, description="Optional invitation message")


class GetWorkspaceInvitationsInput(BaseModel):
    """Input for get_workspace_invitations tool."""
    workspace_id: str = Field(description="The ID of the workspace to get invitations for")


class GetWorkspaceWalletInput(BaseModel):
    """Input for get_workspace_wallet tool."""
    workspace_id: str = Field(description="The ID of the workspace to get wallet details for")


class CreateWorkspaceTokenRequestInput(BaseModel):
    """Input for create_workspace_token_request tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    amount: int = Field(description="Number of tokens requested")
    reason: str = Field(description="Reason for the token request")


class ReviewWorkspaceTokenRequestInput(BaseModel):
    """Input for review_workspace_token_request tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    request_id: str = Field(description="The ID of the token request to review")
    action: str = Field(description="Action to take: approve or deny")
    comments: Optional[str] = Field(default=None, description="Optional comments about the decision")


class GetWorkspaceTokenRequestsInput(BaseModel):
    """Input for get_workspace_token_requests tool."""
    workspace_id: str = Field(description="The ID of the workspace to get token requests for")


class UpdateWalletPermissionsInput(BaseModel):
    """Input for update_wallet_permissions tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    user_id: str = Field(description="The ID of the user to update permissions for")
    can_spend: bool = Field(description="Whether the user can spend from the wallet")
    spending_limit: int = Field(default=0, description="Maximum spending limit for the user")


class FreezeWorkspaceWalletInput(BaseModel):
    """Input for freeze_workspace_wallet tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    reason: str = Field(description="Reason for freezing the wallet")


class UnfreezeWorkspaceWalletInput(BaseModel):
    """Input for unfreeze_workspace_wallet tool."""
    workspace_id: str = Field(description="The ID of the workspace to unfreeze wallet for")


class GetWorkspaceTransactionHistoryInput(BaseModel):
    """Input for get_workspace_transaction_history tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    limit: int = Field(default=50, description="Maximum number of transactions to return")
    offset: int = Field(default=0, description="Number of transactions to skip")


class GetWorkspaceAuditLogInput(BaseModel):
    """Input for get_workspace_audit_log tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    limit: int = Field(default=50, description="Maximum number of audit entries to return")
    offset: int = Field(default=0, description="Number of entries to skip")


class DesignateBackupAdminInput(BaseModel):
    """Input for designate_backup_admin tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    user_id: str = Field(description="The ID of the user to designate as backup admin")


class RemoveBackupAdminInput(BaseModel):
    """Input for remove_backup_admin tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    user_id: str = Field(description="The ID of the backup admin to remove")


class EmergencyWorkspaceAccessInput(BaseModel):
    """Input for emergency_workspace_access tool."""
    workspace_id: str = Field(description="The ID of the workspace")
    reason: str = Field(description="Reason for emergency access")


class GetWorkspaceAnalyticsInput(BaseModel):
    """Input for get_workspace_analytics tool."""
    workspace_id: str = Field(description="The ID of the workspace to get analytics for")


class ValidateWorkspaceAccessInput(BaseModel):
    """Input for validate_workspace_access tool."""
    workspace_id: str = Field(description="The ID of the workspace to validate access for")


class GetWorkspaceHealthInput(BaseModel):
    """Input for get_workspace_health tool."""
    workspace_id: str = Field(description="The ID of the workspace to check health for")


def create_workspace_tools(user_context: MCPUserContext) -> List[StructuredTool]:
    """Create LangChain wrappers for workspace MCP tools.
    
    This function creates StructuredTool instances for all workspace-related
    MCP tools, enabling LangChain agents to manage workspaces, members, wallets,
    and other workspace operations.
    
    Args:
        user_context: MCP user context containing authentication and permissions
        
    Returns:
        List of StructuredTool instances for workspace management
    """
    tools = []
    
    # Basic workspace operations
    if hasattr(mcp_workspace, 'get_user_workspaces'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_user_workspaces",
            description="Get all workspaces that the current user belongs to",
            func=get_func(mcp_workspace.get_user_workspaces),
            user_context=user_context,
        ))
    
    if hasattr(mcp_workspace, 'create_workspace'):
        tools.append(create_langchain_tool_from_mcp(
            name="create_workspace",
            description="Create a new workspace for team collaboration",
            func=get_func(mcp_workspace.create_workspace),
            user_context=user_context,
            args_schema=CreateWorkspaceInput,
        ))
    
    if hasattr(mcp_workspace, 'get_workspace_details'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_details",
            description="Get detailed information about a specific workspace",
            func=get_func(mcp_workspace.get_workspace_details),
            user_context=user_context,
            args_schema=GetWorkspaceDetailsInput,
        ))
    
    if hasattr(mcp_workspace, 'update_workspace'):
        tools.append(create_langchain_tool_from_mcp(
            name="update_workspace",
            description="Update workspace information and settings (admin only)",
            func=get_func(mcp_workspace.update_workspace),
            user_context=user_context,
            args_schema=UpdateWorkspaceInput,
        ))
    
    if hasattr(mcp_workspace, 'delete_workspace'):
        tools.append(create_langchain_tool_from_mcp(
            name="delete_workspace",
            description="Delete a workspace permanently (admin only, requires confirmation)",
            func=get_func(mcp_workspace.delete_workspace),
            user_context=user_context,
            args_schema=DeleteWorkspaceInput,
        ))
    
    if hasattr(mcp_workspace, 'get_workspace_settings'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_settings",
            description="Get workspace settings and configuration",
            func=get_func(mcp_workspace.get_workspace_settings),
            user_context=user_context,
            args_schema=GetWorkspaceSettingsInput,
        ))
    
    # Member management
    if hasattr(mcp_workspace, 'add_workspace_member'):
        tools.append(create_langchain_tool_from_mcp(
            name="add_workspace_member",
            description="Add a member to the workspace",
            func=get_func(mcp_workspace.add_workspace_member),
            user_context=user_context,
            args_schema=AddWorkspaceMemberInput,
        ))
    
    if hasattr(mcp_workspace, 'remove_workspace_member'):
        tools.append(create_langchain_tool_from_mcp(
            name="remove_workspace_member",
            description="Remove a member from the workspace",
            func=get_func(mcp_workspace.remove_workspace_member),
            user_context=user_context,
            args_schema=RemoveWorkspaceMemberInput,
        ))
    
    if hasattr(mcp_workspace, 'update_member_role'):
        tools.append(create_langchain_tool_from_mcp(
            name="update_member_role",
            description="Update a workspace member's role",
            func=get_func(mcp_workspace.update_member_role),
            user_context=user_context,
            args_schema=UpdateMemberRoleInput,
        ))
    
    if hasattr(mcp_workspace, 'get_workspace_members'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_members",
            description="Get all members of a workspace",
            func=get_func(mcp_workspace.get_workspace_members),
            user_context=user_context,
            args_schema=GetWorkspaceMembersInput,
        ))
    
    if hasattr(mcp_workspace, 'invite_workspace_member'):
        tools.append(create_langchain_tool_from_mcp(
            name="invite_workspace_member",
            description="Invite a user to join the workspace via email",
            func=get_func(mcp_workspace.invite_workspace_member),
            user_context=user_context,
            args_schema=InviteWorkspaceMemberInput,
        ))
    
    if hasattr(mcp_workspace, 'get_workspace_invitations'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_invitations",
            description="Get all pending invitations for a workspace",
            func=get_func(mcp_workspace.get_workspace_invitations),
            user_context=user_context,
            args_schema=GetWorkspaceInvitationsInput,
        ))
    
    # Wallet and financial operations
    if hasattr(mcp_workspace, 'get_workspace_wallet'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_wallet",
            description="Get workspace wallet balance and details",
            func=get_func(mcp_workspace.get_workspace_wallet),
            user_context=user_context,
            args_schema=GetWorkspaceWalletInput,
        ))
    
    if hasattr(mcp_workspace, 'create_workspace_token_request'):
        tools.append(create_langchain_tool_from_mcp(
            name="create_workspace_token_request",
            description="Create a request for additional workspace tokens",
            func=get_func(mcp_workspace.create_workspace_token_request),
            user_context=user_context,
            args_schema=CreateWorkspaceTokenRequestInput,
        ))
    
    if hasattr(mcp_workspace, 'review_workspace_token_request'):
        tools.append(create_langchain_tool_from_mcp(
            name="review_workspace_token_request",
            description="Review and approve/deny a token request (admin only)",
            func=get_func(mcp_workspace.review_workspace_token_request),
            user_context=user_context,
            args_schema=ReviewWorkspaceTokenRequestInput,
        ))
    
    if hasattr(mcp_workspace, 'get_workspace_token_requests'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_token_requests",
            description="Get all token requests for a workspace",
            func=get_func(mcp_workspace.get_workspace_token_requests),
            user_context=user_context,
            args_schema=GetWorkspaceTokenRequestsInput,
        ))
    
    if hasattr(mcp_workspace, 'update_wallet_permissions'):
        tools.append(create_langchain_tool_from_mcp(
            name="update_wallet_permissions",
            description="Update wallet spending permissions for a member",
            func=get_func(mcp_workspace.update_wallet_permissions),
            user_context=user_context,
            args_schema=UpdateWalletPermissionsInput,
        ))
    
    if hasattr(mcp_workspace, 'freeze_workspace_wallet'):
        tools.append(create_langchain_tool_from_mcp(
            name="freeze_workspace_wallet",
            description="Freeze workspace wallet to prevent spending",
            func=get_func(mcp_workspace.freeze_workspace_wallet),
            user_context=user_context,
            args_schema=FreezeWorkspaceWalletInput,
        ))
    
    if hasattr(mcp_workspace, 'unfreeze_workspace_wallet'):
        tools.append(create_langchain_tool_from_mcp(
            name="unfreeze_workspace_wallet",
            description="Unfreeze workspace wallet to allow spending",
            func=get_func(mcp_workspace.unfreeze_workspace_wallet),
            user_context=user_context,
            args_schema=UnfreezeWorkspaceWalletInput,
        ))
    
    if hasattr(mcp_workspace, 'get_workspace_transaction_history'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_transaction_history",
            description="Get transaction history for a workspace wallet",
            func=get_func(mcp_workspace.get_workspace_transaction_history),
            user_context=user_context,
            args_schema=GetWorkspaceTransactionHistoryInput,
        ))
    
    # Audit and monitoring
    if hasattr(mcp_workspace, 'get_workspace_audit_log'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_audit_log",
            description="Get audit log of all workspace activities",
            func=get_func(mcp_workspace.get_workspace_audit_log),
            user_context=user_context,
            args_schema=GetWorkspaceAuditLogInput,
        ))
    
    # Admin and emergency operations
    if hasattr(mcp_workspace, 'designate_backup_admin'):
        tools.append(create_langchain_tool_from_mcp(
            name="designate_backup_admin",
            description="Designate a backup admin for emergency access",
            func=get_func(mcp_workspace.designate_backup_admin),
            user_context=user_context,
            args_schema=DesignateBackupAdminInput,
        ))
    
    if hasattr(mcp_workspace, 'remove_backup_admin'):
        tools.append(create_langchain_tool_from_mcp(
            name="remove_backup_admin",
            description="Remove a backup admin designation",
            func=get_func(mcp_workspace.remove_backup_admin),
            user_context=user_context,
            args_schema=RemoveBackupAdminInput,
        ))
    
    if hasattr(mcp_workspace, 'emergency_workspace_access'):
        tools.append(create_langchain_tool_from_mcp(
            name="emergency_workspace_access",
            description="Request emergency access to a workspace (backup admin only)",
            func=get_func(mcp_workspace.emergency_workspace_access),
            user_context=user_context,
            args_schema=EmergencyWorkspaceAccessInput,
        ))
    
    # Analytics and health
    if hasattr(mcp_workspace, 'get_workspace_analytics'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_analytics",
            description="Get analytics and usage statistics for a workspace",
            func=get_func(mcp_workspace.get_workspace_analytics),
            user_context=user_context,
            args_schema=GetWorkspaceAnalyticsInput,
        ))
    
    if hasattr(mcp_workspace, 'validate_workspace_access'):
        tools.append(create_langchain_tool_from_mcp(
            name="validate_workspace_access",
            description="Validate user access permissions for a workspace",
            func=get_func(mcp_workspace.validate_workspace_access),
            user_context=user_context,
            args_schema=ValidateWorkspaceAccessInput,
        ))
    
    if hasattr(mcp_workspace, 'get_workspace_health'):
        tools.append(create_langchain_tool_from_mcp(
            name="get_workspace_health",
            description="Get health status and diagnostics for a workspace",
            func=get_func(mcp_workspace.get_workspace_health),
            user_context=user_context,
            args_schema=GetWorkspaceHealthInput,
        ))
    
    return tools
