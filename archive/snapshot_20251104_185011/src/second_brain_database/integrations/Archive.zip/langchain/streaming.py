"""Streaming support for LangChain agents."""
import asyncio
from typing import AsyncIterator, Dict, Any
from langchain_core.callbacks import AsyncCallbackHandler
from langchain_core.outputs import LLMResult
from ...models.ai_models import StreamingChunk
from ...managers.logging_manager import get_logger

logger = get_logger(prefix="[Streaming]")


class StreamingCallbackHandler(AsyncCallbackHandler):
    """Callback handler for streaming LLM responses."""
    
    def __init__(self):
        """Initialize streaming handler."""
        self.queue: asyncio.Queue = asyncio.Queue()
        self.sequence = 0
        self.is_done = False
    
    async def on_llm_new_token(self, token: str, **kwargs: Any) -> None:
        """Handle new token from LLM."""
        chunk = StreamingChunk(
            chunk_type="text",
            content=token,
            sequence=self.sequence,
            is_final=False,
        )
        self.sequence += 1
        await self.queue.put(chunk)
    
    async def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        """Handle LLM completion."""
        chunk = StreamingChunk(
            chunk_type="text",
            content="",
            sequence=self.sequence,
            is_final=True,
            metadata={"llm_output": response.llm_output},
        )
        await self.queue.put(chunk)
        self.is_done = True
    
    async def on_llm_error(self, error: Exception, **kwargs: Any) -> None:
        """Handle LLM error."""
        chunk = StreamingChunk(
            chunk_type="error",
            content=str(error),
            sequence=self.sequence,
            is_final=True,
        )
        await self.queue.put(chunk)
        self.is_done = True
    
    async def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> None:
        """Handle tool execution start."""
        chunk = StreamingChunk(
            chunk_type="tool_call",
            content={
                "action": "start",
                "tool": serialized.get("name", "unknown"),
                "input": input_str,
            },
            sequence=self.sequence,
            is_final=False,
        )
        self.sequence += 1
        await self.queue.put(chunk)
    
    async def on_tool_end(self, output: str, **kwargs: Any) -> None:
        """Handle tool execution end."""
        chunk = StreamingChunk(
            chunk_type="tool_call",
            content={
                "action": "end",
                "output": output,
            },
            sequence=self.sequence,
            is_final=False,
        )
        self.sequence += 1
        await self.queue.put(chunk)
    
    async def aiter(self) -> AsyncIterator[StreamingChunk]:
        """Async iterator for streaming chunks."""
        while not self.is_done or not self.queue.empty():
            try:
                chunk = await asyncio.wait_for(self.queue.get(), timeout=0.1)
                yield chunk
            except asyncio.TimeoutError:
                continue


async def stream_agent_response(
    agent_executor,
    input_data: Dict[str, Any],
) -> AsyncIterator[StreamingChunk]:
    """Stream agent response with callbacks.
    
    Args:
        agent_executor: LangChain agent executor
        input_data: Input data for agent
        
    Yields:
        Streaming chunks
    """
    handler = StreamingCallbackHandler()
    
    # Run agent with streaming callback
    task = asyncio.create_task(
        agent_executor.ainvoke(
            input_data,
            config={"callbacks": [handler]},
        )
    )
    
    # Stream chunks as they arrive
    async for chunk in handler.aiter():
        yield chunk
    
    # Wait for agent to complete
    try:
        await task
    except Exception as e:
        logger.error(f"Agent execution error: {e}")
        yield StreamingChunk(
            chunk_type="error",
            content=str(e),
            sequence=handler.sequence,
            is_final=True,
        )
