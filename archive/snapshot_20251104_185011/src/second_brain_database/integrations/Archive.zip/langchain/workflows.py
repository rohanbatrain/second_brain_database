"""LangGraph StateGraph workflows for complex multi-step tasks.

Implements structured workflows for advanced AI operations.
"""
import operator
from typing import TypedDict, Annotated, Sequence
from langgraph.graph import StateGraph, END
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage

from ...managers.logging_manager import get_logger
from second_brain_database.integrations.mcp.context import MCPUserContext
from .orchestrator import LangChainOrchestrator

logger = get_logger(prefix="[LangGraphWorkflows]")


class AgentState(TypedDict):
    """State for agent workflows."""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    user_context: MCPUserContext
    task_result: dict
    error: str | None


class MultiStepWorkflow:
    """Multi-step task workflow using StateGraph."""
    
    def __init__(self, orchestrator: LangChainOrchestrator):
        """Initialize workflow.
        
        Args:
            orchestrator: LangChain orchestrator instance
        """
        self.orchestrator = orchestrator
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build the workflow graph.
        
        Returns:
            Compiled StateGraph
        """
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("analyze", self.analyze_task)
        workflow.add_node("execute", self.execute_task)
        workflow.add_node("verify", self.verify_result)
        
        # Define edges
        workflow.set_entry_point("analyze")
        workflow.add_edge("analyze", "execute")
        workflow.add_edge("execute", "verify")
        workflow.add_edge("verify", END)
        
        return workflow.compile()
    
    async def analyze_task(self, state: AgentState) -> AgentState:
        """Analyze user task and plan execution.
        
        Args:
            state: Current workflow state
            
        Returns:
            Updated state
        """
        logger.info("Analyzing task...")
        
        try:
            user_msg = state["messages"][-1].content
            
            # Get task analysis from orchestrator
            analysis_prompt = f"Analyze this task and break it into steps: {user_msg}"
            response = await self.orchestrator.chat(
                session_id=state["user_context"].session_id,
                message=analysis_prompt,
                user_context=state["user_context"],
            )
            
            state["messages"].append(AIMessage(content=response["response"]))
            logger.info(f"Task analysis complete: {response['response'][:100]}...")
            
        except Exception as e:
            logger.error(f"Task analysis failed: {e}")
            state["error"] = str(e)
        
        return state
    
    async def execute_task(self, state: AgentState) -> AgentState:
        """Execute the task using available tools.
        
        Args:
            state: Current workflow state
            
        Returns:
            Updated state
        """
        logger.info("Executing task...")
        
        try:
            if state.get("error"):
                return state
            
            # Execute task with tools
            user_msg = state["messages"][0].content
            response = await self.orchestrator.chat(
                session_id=state["user_context"].session_id,
                message=f"Execute this task: {user_msg}",
                user_context=state["user_context"],
            )
            
            state["task_result"] = response
            state["messages"].append(AIMessage(content=response["response"]))
            logger.info("Task execution complete")
            
        except Exception as e:
            logger.error(f"Task execution failed: {e}")
            state["error"] = str(e)
        
        return state
    
    async def verify_result(self, state: AgentState) -> AgentState:
        """Verify task execution result.
        
        Args:
            state: Current workflow state
            
        Returns:
            Updated state
        """
        logger.info("Verifying result...")
        
        try:
            if state.get("error"):
                state["messages"].append(AIMessage(content=f"Task failed: {state['error']}"))
                return state
            
            # Verify the result
            result = state.get("task_result", {})
            verification_msg = f"Task completed successfully. Result: {result.get('response', 'No response')}"
            state["messages"].append(AIMessage(content=verification_msg))
            logger.info("Result verification complete")
            
        except Exception as e:
            logger.error(f"Result verification failed: {e}")
            state["error"] = str(e)
        
        return state
    
    async def run(self, user_message: str, user_context: MCPUserContext) -> dict:
        """Run the workflow.
        
        Args:
            user_message: User's task request
            user_context: MCP user context
            
        Returns:
            Workflow result
        """
        initial_state = AgentState(
            messages=[HumanMessage(content=user_message)],
            user_context=user_context,
            task_result={},
            error=None,
        )
        
        final_state = await self.graph.ainvoke(initial_state)
        
        return {
            "messages": [msg.content for msg in final_state["messages"]],
            "result": final_state.get("task_result"),
            "error": final_state.get("error"),
        }


class ShoppingWorkflow:
    """Workflow for shopping tasks (browse, select, purchase)."""
    
    def __init__(self, orchestrator: LangChainOrchestrator):
        """Initialize shopping workflow.
        
        Args:
            orchestrator: LangChain orchestrator instance
        """
        self.orchestrator = orchestrator
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build shopping workflow graph."""
        workflow = StateGraph(AgentState)
        
        workflow.add_node("browse", self.browse_shop)
        workflow.add_node("select", self.select_item)
        workflow.add_node("purchase", self.purchase_item)
        
        workflow.set_entry_point("browse")
        workflow.add_edge("browse", "select")
        workflow.add_edge("select", "purchase")
        workflow.add_edge("purchase", END)
        
        return workflow.compile()
    
    async def browse_shop(self, state: AgentState) -> AgentState:
        """Browse shop items."""
        logger.info("Browsing shop...")
        
        try:
            response = await self.orchestrator.chat(
                session_id=state["user_context"].session_id,
                message="Show me available shop items",
                user_context=state["user_context"],
            )
            
            state["messages"].append(AIMessage(content=response["response"]))
            
        except Exception as e:
            logger.error(f"Browse failed: {e}")
            state["error"] = str(e)
        
        return state
    
    async def select_item(self, state: AgentState) -> AgentState:
        """Select item to purchase."""
        logger.info("Selecting item...")
        
        try:
            if state.get("error"):
                return state
            
            user_msg = state["messages"][0].content
            response = await self.orchestrator.chat(
                session_id=state["user_context"].session_id,
                message=f"Select this item: {user_msg}",
                user_context=state["user_context"],
            )
            
            state["task_result"] = response
            state["messages"].append(AIMessage(content=response["response"]))
            
        except Exception as e:
            logger.error(f"Selection failed: {e}")
            state["error"] = str(e)
        
        return state
    
    async def purchase_item(self, state: AgentState) -> AgentState:
        """Complete purchase."""
        logger.info("Completing purchase...")
        
        try:
            if state.get("error"):
                return state
            
            response = await self.orchestrator.chat(
                session_id=state["user_context"].session_id,
                message="Complete the purchase",
                user_context=state["user_context"],
            )
            
            state["messages"].append(AIMessage(content=response["response"]))
            
        except Exception as e:
            logger.error(f"Purchase failed: {e}")
            state["error"] = str(e)
        
        return state
    
    async def run(self, user_message: str, user_context: MCPUserContext) -> dict:
        """Run shopping workflow."""
        initial_state = AgentState(
            messages=[HumanMessage(content=user_message)],
            user_context=user_context,
            task_result={},
            error=None,
        )
        
        final_state = await self.graph.ainvoke(initial_state)
        
        return {
            "messages": [msg.content for msg in final_state["messages"]],
            "result": final_state.get("task_result"),
            "error": final_state.get("error"),
        }
