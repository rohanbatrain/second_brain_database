"""
Main LangChain orchestrator for AI agents.

Simplified to use the production-ready LangGraph agent with MCP tool integration.
"""
from typing import Dict, List, Optional, Any
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.tools import BaseTool

from .memory.redis_memory import MCPIntegratedMemory
from ..langgraph.graphs.sbd_agent import create_production_graph
from ..langgraph.mcp_bridge import get_mcp_tools_as_langchain_tools, create_simple_langchain_tools
from ...config import Settings
from ...managers.redis_manager import RedisManager
from ...managers.logging_manager import get_logger
from ...integrations.mcp.context import MCPUserContext

logger = get_logger(prefix="[Orchestrator]")


class LangChainOrchestrator:
    """
    Simplified orchestrator that manages LangGraph agents with MCP tools.
    
    This orchestrator:
    - Creates user-specific graphs with appropriate tools
    - Manages conversation memory via Redis
    - Handles agent lifecycle and caching
    """
    
    def __init__(
        self,
        settings: Settings,
        redis_manager: RedisManager,
    ):
        """Initialize orchestrator.
        
        Args:
            settings: Application settings
            redis_manager: Redis manager instance
        """
        self.settings = settings
        self.redis_manager = redis_manager
        
        # Validate LLM provider
        if settings.LANGCHAIN_MODEL_PROVIDER != "ollama":
            raise ValueError(f"Only Ollama is supported currently, got: {settings.LANGCHAIN_MODEL_PROVIDER}")
        
        # Initialize memory
        self.memory = MCPIntegratedMemory(
            redis_manager=redis_manager,
            conversation_history_limit=settings.LANGCHAIN_CONVERSATION_HISTORY_LIMIT,
            ttl=settings.LANGCHAIN_MEMORY_TTL,
        )
        
        # Graph cache - one graph per user
        self.graphs: Dict[str, Any] = {}
        
        logger.info("LangChain orchestrator initialized")
    
    def _get_or_create_graph(self, user_context: MCPUserContext) -> Any:
        """
        Get or create a LangGraph agent for this user.
        
        Args:
            user_context: MCP user context
            
        Returns:
            Compiled LangGraph graph
        """
        user_id = user_context.user_id
        
        # Check cache
        if user_id in self.graphs:
            return self.graphs[user_id]
        
        logger.info(f"Creating new graph for user {user_id}")
        
        # Get MCP tools for this user (respects permissions)
        try:
            tools = get_mcp_tools_as_langchain_tools(user_context)
        except Exception as e:
            logger.warning(f"Failed to get MCP tools, using fallback: {e}")
            tools = create_simple_langchain_tools()
        
        # Create production graph with user's tools
        graph = create_production_graph(
            mcp_tools=tools,
            ollama_host=self.settings.OLLAMA_HOST,
            model=self.settings.LANGCHAIN_DEFAULT_MODEL,
        )
        
        # Cache it
        self.graphs[user_id] = graph
        
        logger.info(f"Created graph for user {user_id} with {len(tools)} tools")
        return graph
    
    async def chat(
        self,
        session_id: str,
        user_id: str,
        message: str,
        user_context: MCPUserContext,
        agent_type: str = "general",  # Kept for compatibility but not used
    ) -> Dict[str, Any]:
        """
        Process a chat message through the LangGraph agent.
        
        Args:
            session_id: Session ID for conversation tracking
            user_id: User ID
            message: User's message
            user_context: MCP user context with permissions
            agent_type: Deprecated - kept for backwards compatibility
            
        Returns:
            Response dictionary with message or error
        """
        try:
            # Get user's graph (with their tools and permissions)
            graph = self._get_or_create_graph(user_context)
            
            # Get conversation history
            history = self.memory.get_chat_history(session_id)
            
            # Build messages list with history + new message
            messages = list(history.messages) + [HumanMessage(content=message)]
            
            # Run the graph
            result = await graph.ainvoke(
                {"messages": messages},
                config={"configurable": {"thread_id": session_id}}
            )
            
            # Extract response
            if not result or "messages" not in result:
                raise ValueError("Graph returned invalid result")
            
            # Get the last AI message
            response_messages = result["messages"]
            last_message = response_messages[-1]
            response_text = last_message.content if hasattr(last_message, 'content') else str(last_message)
            
            # Update memory
            history.add_message(HumanMessage(content=message))
            history.add_message(AIMessage(content=response_text))
            self.memory.trim_history(session_id)
            
            logger.debug(f"Chat response for session {session_id}: {len(response_text)} chars")
            
            return {
                "response": response_text,
                "session_id": session_id,
                "status": "success"
            }
        
        except Exception as e:
            logger.error(f"Chat error for session {session_id}: {e}", exc_info=True)
            return {
                "error": str(e),
                "session_id": session_id,
                "status": "error"
            }
    
    def clear_session(self, session_id: str):
        """
        Clear conversation history for a session.
        
        Args:
            session_id: Session ID to clear
        """
        history = self.memory.get_chat_history(session_id)
        history.clear()
        logger.info(f"Cleared session {session_id}")
    
    def clear_user_graph(self, user_id: str):
        """
        Clear cached graph for a user (e.g., when permissions change).
        
        Args:
            user_id: User ID whose graph to clear
        """
        if user_id in self.graphs:
            del self.graphs[user_id]
            logger.info(f"Cleared graph cache for user {user_id}")
