"""Redis-backed memory for LangChain agents."""
import json
import redis as redis_sync
from typing import List, Optional
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.messages import BaseMessage, message_to_dict, messages_from_dict
from ....managers.redis_manager import RedisManager


class RedisChatMessageHistory(BaseChatMessageHistory):
    """Redis-backed chat message history for LangChain."""
    
    def __init__(
        self,
        session_id: str,
        redis_manager: RedisManager,
        key_prefix: str = "langchain:chat:",
        ttl: int = 3600,
    ):
        """Initialize Redis chat history.
        
        Args:
            session_id: Unique session identifier
            redis_manager: Redis manager instance  
            key_prefix: Prefix for Redis keys
            ttl: TTL in seconds for chat history
        """
        self.session_id = session_id
        self.redis_url = redis_manager.redis_url
        self.key = f"{key_prefix}{session_id}"
        self.ttl = ttl
        # Create sync Redis client for LangChain compatibility
        self._redis_client = redis_sync.from_url(self.redis_url, decode_responses=True)
    
    @property
    def messages(self) -> List[BaseMessage]:
        """Retrieve messages from Redis."""
        try:
            data = self._redis_client.get(self.key)
            if data:
                messages_data = json.loads(data)
                return messages_from_dict(messages_data)
            return []
        except Exception as e:
            print(f"Error retrieving messages: {e}")
            return []
    
    def add_message(self, message: BaseMessage) -> None:
        """Add a message to the Redis store."""
        try:
            current_messages = self.messages
            current_messages.append(message)
            
            messages_data = [message_to_dict(m) for m in current_messages]
            self._redis_client.set(
                self.key,
                json.dumps(messages_data),
                ex=self.ttl
            )
        except Exception as e:
            print(f"Error adding message: {e}")
    
    def clear(self) -> None:
        """Clear all messages from the session."""
        try:
            self._redis_client.delete(self.key)
        except Exception as e:
            print(f"Error clearing messages: {e}")


class MCPIntegratedMemory:
    """Memory management for MCP-integrated LangChain agents."""
    
    def __init__(
        self,
        redis_manager: RedisManager,
        conversation_history_limit: int = 50,
        ttl: int = 3600,
    ):
        """Initialize MCP integrated memory.
        
        Args:
            redis_manager: Redis manager instance
            conversation_history_limit: Max messages to retain
            ttl: TTL in seconds
        """
        self.redis_manager = redis_manager
        self.conversation_history_limit = conversation_history_limit
        self.ttl = ttl
    
    def get_chat_history(self, session_id: str) -> RedisChatMessageHistory:
        """Get chat history for a session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            RedisChatMessageHistory instance
        """
        return RedisChatMessageHistory(
            session_id=session_id,
            redis_manager=self.redis_manager,
            ttl=self.ttl,
        )
    
    def trim_history(self, session_id: str) -> None:
        """Trim history to conversation limit."""
        try:
            history = self.get_chat_history(session_id)
            messages = history.messages
            
            if len(messages) > self.conversation_history_limit:
                # Keep only the most recent messages
                trimmed = messages[-self.conversation_history_limit:]
                history.clear()
                for msg in trimmed:
                    history.add_message(msg)
        except Exception as e:
            print(f"Error trimming history: {e}")
