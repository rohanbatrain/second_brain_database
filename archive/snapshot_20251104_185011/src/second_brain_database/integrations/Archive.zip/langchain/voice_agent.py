"""Production LiveKit Voice Agent with LangChain + Deepgram integration.

Uses LiveKit Agents framework for real-time audio streaming,
Deepgram Flux for conversational STT, and integrates with LangChain.
"""
import asyncio
import logging
from typing import Optional, Dict, Any
from livekit import rtc, agents
from livekit.agents import JobContext, WorkerOptions, cli
from livekit.agents.llm import ChatContext, ChatMessage
from livekit.agents.voice import Agent as VoiceAgent
from livekit.plugins import deepgram, silero

try:
    from deepgram import DeepgramClient
except ImportError:
    DeepgramClient = None

from ...config import settings, Settings
from ...managers.logging_manager import get_logger
from ...managers.redis_manager import RedisManager
from second_brain_database.integrations.mcp.context import MCPUserContext
from .orchestrator import LangChainOrchestrator

logger = get_logger(prefix="[LiveKitVoiceAgent]")


class SecondBrainVoiceAgent:
    """Production voice agent with LiveKit + LangChain."""
    
    def __init__(self):
        """Initialize voice agent."""
        # Initialize dependencies
        self._settings = Settings()
        self._redis_manager = RedisManager()
        self.orchestrator = LangChainOrchestrator(
            settings=self._settings,
            redis_manager=self._redis_manager
        )
        self.active_sessions: Dict[str, str] = {}  # room_name -> session_id
        
    async def entrypoint(self, ctx: JobContext):
        """LiveKit agent entrypoint for handling voice sessions.
        
        Args:
            ctx: LiveKit job context
        """
        logger.info(f"Voice agent starting for room: {ctx.room.name}")
        
        # Extract user context from room metadata
        user_context = self._extract_user_context(ctx.room.metadata)
        if not user_context:
            logger.error("No user context in room metadata")
            return
        
        # Create LangChain session for this voice conversation
        session_id = await self.orchestrator.create_session(user_context)
        self.active_sessions[ctx.room.name] = session_id
        
        try:
            # Initialize STT (Speech-to-Text) with Deepgram Flux
            stt = deepgram.STT(
                api_key=settings.DEEPGRAM_API_KEY,
                model="nova-2-conversationalai",  # Flux model for voice agents
                language="en-US",
                smart_format=True,
                punctuate=True,
                interim_results=True,
                endpointing=300,  # ms of silence before finalizing
            )
            
            # Initialize TTS (Text-to-Speech) with Silero
            tts = silero.TTS()
            
            # Create LangChain LLM function
            async def llm_function(chat_ctx: ChatContext) -> str:
                """Process voice input through LangChain orchestrator.
                
                Args:
                    chat_ctx: LiveKit chat context
                    
                Returns:
                    AI response text
                """
                # Get latest user message
                user_msg = chat_ctx.messages[-1].content
                
                # Process through LangChain with MCP tools
                response = await self.orchestrator.chat(
                    session_id=session_id,
                    message=user_msg,
                    user_context=user_context,
                )
                
                return response["response"]
            
            # Create voice assistant with new Agent API
            assistant = VoiceAgent(
                instructions="You are a helpful AI assistant with access to user's Second Brain data, families, workspaces, and shop. You can help manage tasks, purchases, and team collaboration.",
                vad=silero.VAD.load(),  # Voice Activity Detection
                stt=stt,
                llm=llm_function,
                tts=tts,
                chat_ctx=ChatContext(
                    messages=[
                        ChatMessage(
                            role="system",
                            content="You are a helpful AI assistant with access to user's Second Brain data."
                        )
                    ]
                ),
            )
            
            # Start voice assistant
            assistant.start(ctx.room)
            
            # Handle participant events
            @ctx.room.on("participant_connected")
            def on_participant_connected(participant: rtc.RemoteParticipant):
                logger.info(f"Participant connected: {participant.identity}")
                
            @ctx.room.on("participant_disconnected")
            def on_participant_disconnected(participant: rtc.RemoteParticipant):
                logger.info(f"Participant disconnected: {participant.identity}")
            
            # Wait for room to finish
            await assistant.aclose()
            
        finally:
            # Cleanup session
            if session_id in self.orchestrator.sessions:
                del self.orchestrator.sessions[session_id]
            if ctx.room.name in self.active_sessions:
                del self.active_sessions[ctx.room.name]
            
            logger.info(f"Voice agent finished for room: {ctx.room.name}")
    
    def _extract_user_context(self, metadata: str) -> Optional[MCPUserContext]:
        """Extract user context from room metadata.
        
        Args:
            metadata: JSON-encoded room metadata
            
        Returns:
            MCP user context or None
        """
        try:
            import json
            data = json.loads(metadata) if metadata else {}
            
            if not data.get("user_id"):
                return None
            
            return MCPUserContext(
                user_id=data["user_id"],
                username=data.get("username", "user"),
                role=data.get("role", "user"),
                email=data.get("email"),
                session_id=data.get("session_id"),
            )
        except Exception as e:
            logger.error(f"Failed to extract user context: {e}")
            return None


# Create global agent instance
voice_agent = SecondBrainVoiceAgent()


def start_voice_worker():
    """Start LiveKit voice worker process.
    
    This should be run as a separate worker process alongside the main FastAPI server.
    
    Raises:
        SystemExit: If LiveKit configuration is invalid or server is not available
    """
    import sys
    import socket
    from urllib.parse import urlparse
    
    # Validate LiveKit configuration
    if not settings.LIVEKIT_API_KEY:
        logger.error("LIVEKIT_API_KEY is not configured")
        logger.error("Set LiveKit credentials in .sbd or .env file")
        sys.exit(1)
    
    if not settings.LIVEKIT_API_SECRET:
        logger.error("LIVEKIT_API_SECRET is not configured")
        logger.error("Set LiveKit credentials in .sbd or .env file")
        sys.exit(1)
    
    # Warn if using dev credentials (but allow them for development)
    if settings.LIVEKIT_API_KEY == "devkey" or settings.LIVEKIT_API_SECRET == "secret":
        logger.warning("Using dev credentials - OK for development with 'livekit-server --dev'")
        logger.warning("For production, generate real credentials from LiveKit Cloud or self-hosted server")
    
    if not settings.LIVEKIT_URL:
        logger.error("LIVEKIT_URL is not configured")
        logger.error("Set LIVEKIT_URL in .sbd or .env file (e.g., ws://localhost:7880)")
        sys.exit(1)
    
    # Check if LiveKit server is reachable
    try:
        parsed = urlparse(settings.LIVEKIT_URL)
        host = parsed.hostname or 'localhost'
        port = parsed.port or 7880
        
        logger.info(f"Checking LiveKit server connectivity: {host}:{port}")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex((host, port))
        sock.close()
        
        if result != 0:
            logger.error(f"Cannot connect to LiveKit server at {host}:{port}")
            logger.error("LiveKit server is not running!")
            logger.error("Install and start LiveKit server:")
            logger.error("  - macOS: brew install livekit-server && livekit-server --dev")
            logger.error("  - Docker: docker run -p 7880:7880 livekit/livekit-server --dev")
            logger.error("  - Download: https://docs.livekit.io/home/self-hosting/local/")
            sys.exit(1)
        
        logger.info(f"✓ LiveKit server is reachable at {host}:{port}")
        
    except Exception as e:
        logger.error(f"Failed to check LiveKit server connectivity: {e}")
        logger.error("Make sure LiveKit server is running before starting voice worker")
        sys.exit(1)
    
    # Check Deepgram API key
    if not settings.DEEPGRAM_API_KEY:
        logger.warning("DEEPGRAM_API_KEY is not configured")
        logger.warning("Voice transcription will not work without Deepgram API key")
        logger.warning("Get API key from: https://deepgram.com/")
    
    # Add 'start' command for production mode
    if len(sys.argv) == 1:
        sys.argv.append('start')
    
    logger.info("Starting LiveKit voice worker...")
    logger.info(f"  Server: {settings.LIVEKIT_URL}")
    logger.info(f"  API Key: {settings.LIVEKIT_API_KEY[:8]}...")
    
    try:
        cli.run_app(
            WorkerOptions(
                entrypoint_fnc=voice_agent.entrypoint,
                api_key=settings.LIVEKIT_API_KEY,
                api_secret=settings.LIVEKIT_API_SECRET,
                ws_url=settings.LIVEKIT_URL,
            )
        )
    except RuntimeError as e:
        if "can't start new thread" in str(e):
            logger.error("FATAL: LiveKit worker failed - cannot spawn threads")
            logger.error("This usually means:")
            logger.error("  1. System resource limits reached")
            logger.error("  2. LiveKit server crashed or not responding")
            logger.error("  3. Too many worker processes already running")
            logger.error("Check: ps aux | grep livekit")
            logger.error("Check: ulimit -a")
            sys.exit(1)
        raise
    except Exception as e:
        logger.error(f"LiveKit worker crashed: {e}")
        raise


if __name__ == "__main__":
    start_voice_worker()
