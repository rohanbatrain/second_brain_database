"""
Platform-Adaptive Configuration for Second Brain Agent
======================================================

Detects hardware and loads optimized settings from .sbd files.
Automatically adjusts workers, batch sizes, and model parameters based on:
- CPU cores
- RAM
- GPU availability (Apple Silicon Neural Engine)
"""

import os
import platform
import psutil
from pathlib import Path
from typing import Dict, Any, Optional
import json


class PlatformConfig:
    """Detects platform capabilities and provides optimized settings"""
    
    def __init__(self):
        self.cpu_count = psutil.cpu_count(logical=True)
        self.physical_cores = psutil.cpu_count(logical=False)
        self.ram_gb = psutil.virtual_memory().total / (1024**3)
        self.system = platform.system()
        self.machine = platform.machine()
        self.is_apple_silicon = self.machine == "arm64" and self.system == "Darwin"
        
    def get_profile(self) -> str:
        """Determine performance profile based on hardware"""
        if self.is_apple_silicon and self.ram_gb >= 16:
            return "m4_16gb"  # M3/M4 with 16GB+
        elif self.is_apple_silicon and self.ram_gb >= 8:
            return "apple_silicon_8gb"
        elif self.ram_gb >= 32:
            return "high_performance"
        elif self.ram_gb >= 16:
            return "standard"
        else:
            return "low_resource"
    
    def get_worker_count(self) -> int:
        """Calculate optimal worker count"""
        profile = self.get_profile()
        
        if profile == "m4_16gb":
            # M4 16GB: Use more workers, Neural Engine handles parallel inference well
            return min(8, self.physical_cores)
        elif profile == "apple_silicon_8gb":
            return min(4, self.physical_cores)
        elif profile == "high_performance":
            return min(12, self.physical_cores * 2)
        elif profile == "standard":
            return min(6, self.physical_cores)
        else:
            return 2
    
    def get_ollama_settings(self) -> Dict[str, Any]:
        """Get Ollama model settings optimized for platform"""
        profile = self.get_profile()
        
        if profile == "m4_16gb":
            return {
                "model": "llama3.2:latest",
                "temperature": 0.7,
                "num_ctx": 8192,  # Larger context for M4
                "num_predict": 1024,  # More tokens
                "num_gpu": 1,  # Use Neural Engine
                "num_thread": self.physical_cores,
                "repeat_penalty": 1.1,
                "top_k": 40,
                "top_p": 0.9,
                "streaming": False,
                "verbose": False,
            }
        elif profile == "apple_silicon_8gb":
            return {
                "model": "llama3.2:latest",
                "temperature": 0.7,
                "num_ctx": 4096,
                "num_predict": 512,
                "num_gpu": 1,
                "num_thread": self.physical_cores,
                "repeat_penalty": 1.1,
                "streaming": False,
                "verbose": False,
            }
        else:
            # Conservative settings for other platforms
            return {
                "model": "llama3.2:latest",
                "temperature": 0.7,
                "num_ctx": 2048,
                "num_predict": 256,
                "repeat_penalty": 1.1,
                "streaming": False,
                "verbose": False,
            }
    
    def get_batch_size(self) -> int:
        """Optimal batch size for parallel processing"""
        profile = self.get_profile()
        
        if profile == "m4_16gb":
            return 16  # M4 can handle larger batches
        elif profile == "apple_silicon_8gb":
            return 8
        elif profile == "high_performance":
            return 12
        else:
            return 4
    
    def to_dict(self) -> Dict[str, Any]:
        """Export all settings as dict"""
        return {
            "platform": {
                "cpu_count": self.cpu_count,
                "physical_cores": self.physical_cores,
                "ram_gb": round(self.ram_gb, 2),
                "system": self.system,
                "machine": self.machine,
                "is_apple_silicon": self.is_apple_silicon,
                "profile": self.get_profile(),
            },
            "langgraph": {
                "workers": self.get_worker_count(),
                "batch_size": self.get_batch_size(),
            },
            "ollama": self.get_ollama_settings(),
        }


def load_sbd_config(config_name: str = "production") -> Dict[str, Any]:
    """
    Load configuration from .sbd file
    
    .sbd files are JSON-based config files for Second Brain Database
    Located in config-templates/ directory
    """
    config_dir = Path(__file__).parent.parent.parent.parent.parent / "config-templates"
    sbd_file = config_dir / f"{config_name}.sbd"
    
    if sbd_file.exists():
        with open(sbd_file, 'r') as f:
            return json.load(f)
    else:
        return {}


def get_optimized_config() -> Dict[str, Any]:
    """
    Get platform-optimized configuration
    
    Priority:
    1. .sbd file overrides
    2. Platform auto-detection
    3. Safe defaults
    """
    platform_config = PlatformConfig()
    auto_config = platform_config.to_dict()
    
    # Try to load .sbd overrides
    sbd_config = load_sbd_config("production")
    
    # Merge configs (sbd overrides auto-detected)
    if sbd_config:
        # Deep merge
        for key, value in sbd_config.items():
            if isinstance(value, dict) and key in auto_config:
                auto_config[key].update(value)
            else:
                auto_config[key] = value
    
    return auto_config


# Export singleton instance
_platform_config = PlatformConfig()

# Export optimized settings
PLATFORM_INFO = _platform_config.to_dict()
WORKERS = _platform_config.get_worker_count()
OLLAMA_SETTINGS = _platform_config.get_ollama_settings()
BATCH_SIZE = _platform_config.get_batch_size()


if __name__ == "__main__":
    # Print current platform config
    import pprint
    print("🖥️  Platform Configuration")
    print("=" * 60)
    pprint.pprint(get_optimized_config(), width=60, indent=2)
    print("\n✅ Configuration loaded successfully!")
