"""
Ollama Integration Configuration
==================================

Implements best practices from:
- https://docs.langchain.com/oss/python/integrations/chat/ollama  
- https://docs.langchain.com/oss/python/integrations/text_embedding/ollama

Features:
- Optimized ChatOllama with streaming
- OllamaEmbeddings for semantic search
- Production-ready callbacks and error handling
"""

from typing import Optional, List
from langchain_ollama import ChatOllama, OllamaEmbeddings
from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
import logging

# Import platform-adaptive configuration
from .platform_config import PLATFORM_INFO, OLLAMA_SETTINGS as PLATFORM_OLLAMA_SETTINGS

logger = logging.getLogger(__name__)


# ============================================================================
# OLLAMA CHAT INTEGRATION
# ============================================================================

class SecondBrainCallbackHandler(BaseCallbackHandler):
    """Custom callback handler for Second Brain Agent"""
    
    def on_llm_start(self, serialized, prompts, **kwargs):
        logger.debug(f"LLM started with {len(prompts)} prompts")
    
    def on_llm_end(self, response, **kwargs):
        tokens = response.llm_output.get("token_usage", {}) if hasattr(response, "llm_output") else {}
        logger.debug(f"LLM completed - {tokens}")
    
    def on_llm_error(self, error, **kwargs):
        logger.error(f"LLM error: {error}")


def get_optimized_chat_ollama(
    model: str = "deepseek-r1:1.5b",
    temperature: float = 0.7,
    streaming: bool = False,
    verbose: bool = False,
    **kwargs
) -> ChatOllama:
    """
    Get optimized ChatOllama instance with best practices.
    
    Args:
        model: Ollama model name (default: deepseek-r1:1.5b)
        temperature: Sampling temperature 0.0-1.0
        streaming: Enable streaming responses
        verbose: Enable verbose logging
        **kwargs: Additional ChatOllama parameters
    
    Returns:
        Configured ChatOllama instance
    
    Best Practices Applied:
    - Temperature tuning for creativity vs consistency
    - Streaming for better UX
    - Custom callbacks for monitoring
    - Error handling and retries
    """
    callbacks = [SecondBrainCallbackHandler()]
    
    if streaming:
        callbacks.append(StreamingStdOutCallbackHandler())
    
    return ChatOllama(
        model=model,
        temperature=temperature,
        callbacks=callbacks if callbacks else None,
        verbose=verbose,
        # Performance optimizations
        num_ctx=2048,  # Reduced context window for faster inference
        num_predict=256,  # Reduced max output tokens for speed
        repeat_penalty=1.1,  # Reduce repetition
        # Speed optimizations
        num_thread=4,  # Use 4 CPU threads
        # Error handling
        request_timeout=60.0,  # Reduced timeout for faster failures
        **kwargs
    )


# ============================================================================
# OLLAMA EMBEDDINGS INTEGRATION  
# ============================================================================

def get_ollama_embeddings(
    model: str = "llama3.2:3b",
    **kwargs
) -> OllamaEmbeddings:
    """
    Get OllamaEmbeddings for semantic search and memory.
    
    Args:
        model: Ollama embedding model
        **kwargs: Additional parameters
    
    Returns:
        Configured OllamaEmbeddings instance
    
    Use Cases:
    - Semantic search across documents
    - Long-term memory storage
    - Similarity matching
    - Document clustering
    """
    return OllamaEmbeddings(
        model=model,
        **kwargs
    )


# ============================================================================
# MODEL PRESETS (Platform-Optimized)
# ============================================================================

# Platform-optimized presets using detected hardware capabilities
# On M4 16GB: num_ctx=8192, num_predict=1024, num_gpu=1, num_thread=8
# On standard systems: Falls back to safe defaults

AGENT_CHAT_MODEL = {
    "model": "llama3.2:latest",
    "temperature": 0.7,
    "streaming": False,
    "verbose": False,
    "num_ctx": PLATFORM_OLLAMA_SETTINGS.get("num_ctx", 4096),
    "num_predict": PLATFORM_OLLAMA_SETTINGS.get("num_predict", 512),
    "num_gpu": PLATFORM_OLLAMA_SETTINGS.get("num_gpu", 1),
    "num_thread": PLATFORM_OLLAMA_SETTINGS.get("num_thread", 4),
    "repeat_penalty": 1.1,
    "request_timeout": 120.0,
}

CREATIVE_CHAT_MODEL = {
    "model": "llama3.2:latest",
    "temperature": 0.9,
    "streaming": True,
    "verbose": False,
    "num_ctx": PLATFORM_OLLAMA_SETTINGS.get("num_ctx", 4096),
    "num_predict": PLATFORM_OLLAMA_SETTINGS.get("num_predict", 512),
    "num_gpu": PLATFORM_OLLAMA_SETTINGS.get("num_gpu", 1),
    "num_thread": PLATFORM_OLLAMA_SETTINGS.get("num_thread", 4),
}

PRECISE_CHAT_MODEL = {
    "model": "llama3.2:latest",
    "temperature": 0.1,
    "streaming": False,
    "verbose": False,
    "num_ctx": PLATFORM_OLLAMA_SETTINGS.get("num_ctx", 4096),
    "num_predict": PLATFORM_OLLAMA_SETTINGS.get("num_predict", 512),
    "num_gpu": PLATFORM_OLLAMA_SETTINGS.get("num_gpu", 1),
    "num_thread": PLATFORM_OLLAMA_SETTINGS.get("num_thread", 4),
}

EMBEDDING_MODEL = {
    "model": "llama3.2:latest",
    "num_ctx": PLATFORM_OLLAMA_SETTINGS.get("num_ctx", 4096),
    "num_gpu": PLATFORM_OLLAMA_SETTINGS.get("num_gpu", 1),
    "num_thread": PLATFORM_OLLAMA_SETTINGS.get("num_thread", 4),
}


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def test_ollama_connection() -> bool:
    """Test if Ollama is accessible"""
    try:
        model = get_optimized_chat_ollama()
        response = model.invoke("test")
        return True
    except Exception as e:
        logger.error(f"Ollama connection failed: {e}")
        return False


def get_available_models() -> List[str]:
    """Get list of available Ollama models"""
    import subprocess
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=10
        )
        lines = result.stdout.strip().split("\n")[1:]  # Skip header
        return [line.split()[0] for line in lines if line.strip()]
    except Exception as e:
        logger.error(f"Failed to get models: {e}")
        return []


if __name__ == "__main__":
    # Test the integration
    print("Testing Ollama integration...")
    print(f"Available models: {get_available_models()}")
    print(f"Connection test: {'✓ OK' if test_ollama_connection() else '✗ FAILED'}")
    
    # Test chat
    chat = get_optimized_chat_ollama(**AGENT_CHAT_MODEL)
    response = chat.invoke("Say 'Hello, I am Second Brain Agent' in 10 words or less")
    print(f"\nAgent response: {response.content}")
    
    # Test embeddings  
    embeddings = get_ollama_embeddings(**EMBEDDING_MODEL)
    vec = embeddings.embed_query("test query")
    print(f"\nEmbedding dimension: {len(vec)}")
