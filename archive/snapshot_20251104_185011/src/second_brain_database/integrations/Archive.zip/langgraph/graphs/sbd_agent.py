"""
Production-Ready LangGraph Agent for Second Brain Database

A simplified, cohesive agent that integrates directly with existing MCP tools.
This implementation follows LangChain/LangGraph best practices without overengineering.

Key Features:
- Direct integration with FastMCP 2.x tools
- Simple state management with TypedDict
- Production-ready error handling
- Proper tool binding and execution
"""

import os
import sys
from typing import Annotated, Sequence, Literal
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from langchain_ollama import ChatOllama

# Add project root to path for absolute imports when run by LangGraph CLI
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
if project_root not in sys.path:
    sys.path.insert(0, project_root)
from langchain_ollama import ChatOllama


# ============================================================================
# State Definition
# ============================================================================

class AgentState(TypedDict):
    """Simple agent state following LangGraph best practices."""
    messages: Annotated[Sequence[BaseMessage], add_messages]


# ============================================================================
# Default Tools (for development/testing)
# ============================================================================

def get_default_tools():
    """
    Get simple default tools for development mode.
    
    In production, these will be replaced by actual MCP tools.
    """
    
    @tool
    def search_shop(query: str) -> str:
        """Search for items in the shop.
        
        Args:
            query: Search query for shop items
        """
        return f"Shop search for '{query}': Found items - Serenity Green Theme ($250), Pacific Blue Theme ($250), Playful Eye Avatar ($2500)"
    
    @tool
    def check_balance() -> str:
        """Check your current SBD token balance."""
        return "Your current balance is 1000 SBD tokens."
    
    @tool
    def get_profile() -> str:
        """Get your profile information."""
        return "Username: dev_user | Role: developer | Member since: 2024"
    
    return [search_shop, check_balance, get_profile]


# ============================================================================
# Graph Logic
# ============================================================================

def should_continue(state: AgentState) -> Literal["tools", "__end__"]:
    """Determine if we should use tools or end the conversation."""
    messages = state["messages"]
    last_message = messages[-1]
    
    # If LLM made tool calls, route to tools
    if hasattr(last_message, "tool_calls") and last_message.tool_calls:
        return "tools"
    
    # Otherwise end
    return "__end__"


def call_model(state: AgentState, llm) -> dict:
    """Call the LLM with current state."""
    messages = state["messages"]
    response = llm.invoke(messages)
    return {"messages": [response]}


# ============================================================================
# Graph Builder
# ============================================================================

def create_agent_graph(llm, tools: list, system_message: str = None):
    """
    Create the agent graph - simplified and production-ready.
    
    Args:
        llm: Language model instance
        tools: List of tools to bind
        system_message: Optional system message
        
    Returns:
        Compiled graph ready for use
    """
    # Bind tools to LLM
    llm_with_tools = llm.bind_tools(tools)
    
    # Create graph
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("agent", lambda state: call_model(state, llm_with_tools))
    workflow.add_node("tools", ToolNode(tools))
    
    # Add edges
    workflow.add_edge(START, "agent")
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", "__end__": END}
    )
    workflow.add_edge("tools", "agent")
    
    # Compile
    return workflow.compile()


# ============================================================================
# Factory Function for LangGraph CLI
# ============================================================================

def create_graph():
    """
    Factory function called by `langgraph dev` and `langgraph up`.
    
    This creates a production-ready graph with environment-based configuration.
    """
    # Get configuration from environment
    ollama_host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    model = os.getenv("LANGCHAIN_DEFAULT_MODEL", "llama3.2:1b")
    temperature = float(os.getenv("LANGCHAIN_TEMPERATURE", "0.7"))
    max_tokens = int(os.getenv("LANGCHAIN_MAX_TOKENS", "2048"))
    
    # Initialize LLM
    llm = ChatOllama(
        model=model,
        base_url=ollama_host,
        temperature=temperature,
        num_predict=max_tokens,
    )
    
    # Get tools - try MCP bridge first, fallback to defaults
    try:
        from second_brain_database.integrations.langgraph.mcp_bridge import get_mcp_tools_as_langchain_tools
        tools = get_mcp_tools_as_langchain_tools()
        print(f"✓ Loaded {len(tools)} MCP tools for LangGraph")
    except Exception as e:
        print(f"⚠ Could not load MCP tools ({e}), using fallback tools")
        import traceback
        traceback.print_exc()
        tools = get_default_tools()
    
    # System message
    system_message = """You are the Second Brain Database AI assistant.

You have comprehensive access to tools for:
- Family Management: Create families, send invitations, manage members, set spending permissions
- Shop Operations: Browse items, search products, make purchases, manage owned assets
- Authentication: Profile management, 2FA setup, security settings
- Workspace: User preferences, notifications, privacy controls
- Admin Operations: User management, system monitoring (for authorized users)

Guidelines:
1. Always use tools to get accurate, real-time data
2. Confirm before executing important actions (purchases, deletions, etc.)
3. Respect user permissions - don't attempt unauthorized operations
4. Be helpful, clear, and concise
5. Format responses in a user-friendly way

You are connected to the production system - your actions are real and will affect the database."""
    
    # Create and return graph
    return create_agent_graph(llm, tools, system_message)


# ============================================================================
# Production Integration (for use with orchestrator)
# ============================================================================

def create_production_graph(mcp_tools: list, ollama_host: str, model: str):
    """
    Create production graph with actual MCP tools.
    
    This is called by the orchestrator when integrating with the main app.
    
    Args:
        mcp_tools: List of MCP tools wrapped as LangChain tools
        ollama_host: Ollama server URL
        model: Model name to use
        
    Returns:
        Compiled production graph
    """
    llm = ChatOllama(
        model=model,
        base_url=ollama_host,
        temperature=0.7,
        num_predict=2048,
    )
    
    system_message = """You are the Second Brain Database AI assistant.

You have access to comprehensive tools for:
- Family management (create, invite, manage members)
- Shop operations (browse, purchase, manage assets)
- Authentication and user management
- Workspace and settings management
- Admin operations (for authorized users)

Always:
1. Use tools to get accurate, real-time information
2. Confirm actions before executing destructive operations
3. Respect user permissions and roles
4. Provide clear, helpful responses

You are integrated with the production system - your actions are real."""
    
    return create_agent_graph(llm, mcp_tools, system_message)


# ============================================================================
# Export for langgraph CLI
# ============================================================================

# This is what `langgraph dev` and `langgraph up` will use
graph = create_graph()
