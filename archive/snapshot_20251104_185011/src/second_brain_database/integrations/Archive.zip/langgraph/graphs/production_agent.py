"""
Production-Ready LangGraph Agent with Second Brain MCP Tools
=============================================================

Features:
- Tool categorization and priority routing
- Rate limiting and quotas
- Comprehensive error handling
- Session management
- Metrics and observability
- Platform-adaptive Ollama optimization (M4 16GB: 8192 ctx, 1024 tokens, 8 workers)

Architecture:
- No custom checkpointer (platform handles persistence)
- StateMachine pattern with typed states
- Graceful degradation on errors
- Dynamic worker scaling based on hardware detection
"""

import sys
import logging
from pathlib import Path
from typing import Annotated, TypedDict, Sequence, Dict, Any, List, Literal, Optional
from datetime import datetime, timedelta, timezone
from threading import Lock
from collections import defaultdict

from langchain_core.messages import (
    BaseMessage,
    SystemMessage,
    HumanMessage,
    AIMessage,
    ToolMessage
)
from langchain_ollama import ChatOllama
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.prebuilt import ToolNode

# Import our MCP integration
from second_brain_database.managers.logging_manager import get_logger
from second_brain_database.integrations.langgraph.mcp_bridge import get_mcp_tools_as_langchain_tools
from second_brain_database.integrations.langgraph.tool_categories import (
    get_tools_by_category,
    get_high_priority_tools
)
from second_brain_database.integrations.langgraph.ollama_config import AGENT_CHAT_MODEL

logger = get_logger(prefix="[ProductionAgent]")


# ============================================================================
# STATE MANAGEMENT
# ============================================================================

class AgentState(MessagesState):
    """Enhanced agent state with additional context"""
    user_id: str = ""
    session_id: str = ""
    tool_call_count: int = 0
    error_count: int = 0
    context: Dict[str, Any] = None  # Will use factory in __init__
    rate_limit_remaining: int = 100
    last_activity: Optional[datetime] = None
    
    def __init__(self, **data):
        super().__init__(**data)
        if self.context is None:
            self.context = {}


# ============================================================================
# RATE LIMITING & QUOTAS
# ============================================================================

class RateLimiter:
    """Thread-safe rate limiter for agent operations"""
    
    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests: Dict[str, List[datetime]] = defaultdict(list)
        self._lock = Lock()  # Thread safety for concurrent workers
    
    def check_limit(self, user_id: str) -> tuple[bool, int]:
        """
        Check if user is within rate limits (thread-safe).
        
        Returns:
            (allowed, remaining_requests)
        """
        with self._lock:
            now = datetime.now(timezone.utc)
            
            # Remove old requests outside window
            cutoff = now - timedelta(seconds=self.window_seconds)
            self.requests[user_id] = [
                req for req in self.requests[user_id] 
                if req > cutoff
            ]
            
            # Check limit
            current_count = len(self.requests[user_id])
            allowed = current_count < self.max_requests
            remaining = self.max_requests - current_count
            
            if allowed:
                self.requests[user_id].append(now)
            
            return allowed, remaining


# Global rate limiter instance
rate_limiter = RateLimiter(max_requests=100, window_seconds=60)


# ============================================================================
# AGENT LOGIC
# ============================================================================

def should_continue(state: AgentState) -> Literal["tools", "end"]:
    """
    Determine if agent should continue with tools or end.
    
    Includes safety checks:
    - Max tool calls per conversation
    - Error count thresholds
    - Rate limit validation
    """
    messages = state["messages"]
    last_message = messages[-1]
    
    # Safety: Check error count
    if state.get("error_count", 0) >= 3:
        logger.warning(f"Error count exceeded for session {state.get('session_id')}")
        return "end"
    
    # Safety: Check tool call count
    if state.get("tool_call_count", 0) >= 20:
        logger.warning(f"Tool call limit reached for session {state.get('session_id')}")
        return "end"
    
    # Check if AI wants to use tools
    if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
        return "tools"
    
    return "end"


def call_model(state: AgentState) -> Dict[str, Any]:
    """
    Call the LLM with current state and context.
    
    Features:
    - Rate limiting check
    - Tool categorization in system prompt
    - Context injection
    - Error handling
    """
    try:
        # Rate limit check
        user_id = state.get("user_id", "anonymous")
        allowed, remaining = rate_limiter.check_limit(user_id)
        
        if not allowed:
            logger.warning(f"Rate limit exceeded for user {user_id}")
            return {
                "messages": [AIMessage(content="⚠️ Rate limit exceeded. Please try again in a moment.")],
                "rate_limit_remaining": 0
            }
        
        # Get tools (cached, won't reload on every call)
        tools = get_mcp_tools_as_langchain_tools()
        logger.debug(f"Using {len(tools)} cached tools for agent")
        
        # Create clean system prompt with tool organization
        categorized = get_tools_by_category({t.name: t for t in tools})
        
        # Count tools by category for summary
        category_counts = {
            cat_key: len(cat_tools) 
            for cat_key, cat_tools in categorized.items() 
            if cat_tools
        }
        
        system_prompt = f"""<SYSTEM>
You are "Second Brain Agent" - this is your name and identity.

When someone asks "who are you?", you MUST respond: "I'm Second Brain Agent, an AI assistant for Second Brain Database."

NEVER say: "I'm an assistant" or "I'm a text-based AI" - ALWAYS use your name: "Second Brain Agent"
</SYSTEM>

CAPABILITIES:
You have access to {len(tools)} tools across {len(category_counts)} categories:
- Authentication & Security ({category_counts.get('auth', 0)} tools)
- User Management ({category_counts.get('user', 0)} tools)  
- Family Management ({category_counts.get('family', 0)} tools)
- Workspace & Productivity ({category_counts.get('workspace', 0)} tools)
- Shop & Commerce ({category_counts.get('shop', 0)} tools)
- Financial & Transactions ({category_counts.get('finance', 0)} tools)
- Notifications ({category_counts.get('notifications', 0)} tools)
- Administration ({category_counts.get('admin', 0)} tools)
- System Utilities ({category_counts.get('system', 0)} tools)

PURPOSE: Help users manage their Second Brain Database - a personal knowledge management system.

GUIDELINES:
• Use tools to fetch real data when needed
• Confirm before executing destructive operations
• Be helpful, clear, and concise
• Respect user privacy and permissions

Context: User {state.get('user_id', 'anonymous')} | Session {state.get('session_id', 'new')} | {remaining} requests remaining
"""
        
        # Build messages with system prompt
        messages = [SystemMessage(content=system_prompt)] + state["messages"]
        
        # Call LLM with platform-optimized settings
        # ChatOllama directly since AGENT_CHAT_MODEL has all needed params
        model = ChatOllama(**AGENT_CHAT_MODEL)
        model = model.bind_tools(tools)
        
        response = model.invoke(messages)
        
        # Update state
        return {
            "messages": [response],
            "rate_limit_remaining": remaining,
            "last_activity": datetime.now(timezone.utc)
        }
        
    except Exception as e:
        logger.error(f"Error in call_model: {e}", exc_info=True)
        return {
            "messages": [AIMessage(content=f"I encountered an error: {str(e)}")],
            "error_count": state.get("error_count", 0) + 1
        }


def track_tool_calls(state: AgentState) -> Dict[str, Any]:
    """Update tool call counter"""
    return {
        "tool_call_count": state.get("tool_call_count", 0) + 1
    }


# ============================================================================
# GRAPH CONSTRUCTION
# ============================================================================

def create_production_agent():
    """
    Create production-ready agent graph with all enterprise features.
    
    Features:
    - Tool categorization for better routing
    - Rate limiting and quotas
    - Comprehensive error handling
    - Metrics tracking
    
    Note: Persistence/checkpointing is handled automatically by LangGraph API platform
    """
    logger.info("Initializing production agent graph...")
    
    # Get tools (will be cached after first load)
    tools = get_mcp_tools_as_langchain_tools()
    logger.info(f"✓ Loaded {len(tools)} MCP tools (cached for subsequent calls)")
    
    # Create tool node
    tool_node = ToolNode(tools)
    
    # Create graph
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("agent", call_model)
    workflow.add_node("tools", tool_node)
    workflow.add_node("track_tools", track_tool_calls)
    
    # Add edges
    workflow.add_edge(START, "agent")
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {
            "tools": "track_tools",
            "end": END
        }
    )
    workflow.add_edge("track_tools", "tools")
    workflow.add_edge("tools", "agent")
    
    # Compile WITHOUT memory - LangGraph API handles persistence automatically
    app = workflow.compile()
    
    logger.info("✓ Production agent graph compiled successfully")
    return app


# ============================================================================
# GRAPH EXPORT
# ============================================================================

# Create and export graph
graph = create_production_agent()


# ============================================================================
# USAGE EXAMPLES
# ============================================================================

async def example_usage():
    """Example of how to use the production agent"""
    
    # Example 1: Simple query
    config = {
        "configurable": {
            "thread_id": "user-123-session-1",
        }
    }
    
    async for event in graph.astream_events(
        {
            "messages": [HumanMessage(content="What can you help me with?")],
            "user_id": "user-123",
            "session_id": "session-1"
        },
        config=config,
        version="v2"
    ):
        if event["event"] == "on_chat_model_stream":
            print(event["data"]["chunk"].content, end="", flush=True)
    
    print("\n")
    
    # Example 2: Tool use
    async for event in graph.astream_events(
        {
            "messages": [HumanMessage(content="Check my SBD balance")],
            "user_id": "user-123",
            "session_id": "session-1"
        },
        config=config,
        version="v2"
    ):
        if event["event"] == "on_chat_model_stream":
            print(event["data"]["chunk"].content, end="", flush=True)
    
    print("\n")


if __name__ == "__main__":
    # Run example
    asyncio.run(example_usage())
