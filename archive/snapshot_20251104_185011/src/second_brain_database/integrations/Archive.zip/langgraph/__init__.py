"""LangGraph integration for Second Brain Database.

Provides LangGraph Platform-compatible API endpoints and graph definitions.
"""
