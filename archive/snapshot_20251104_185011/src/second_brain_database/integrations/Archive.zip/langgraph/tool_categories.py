"""
Tool Categorization System for MCP Tools

Organizes 146+ MCP tools into logical categories for better agent performance.
"""

from typing import Dict, List, Set
from dataclasses import dataclass

@dataclass
class ToolCategory:
    """Represents a category of tools"""
    name: str
    description: str
    keywords: Set[str]
    priority: int  # Lower = higher priority
    require_auth: bool = True
    
TOOL_CATEGORIES: Dict[str, ToolCategory] = {
    "auth": ToolCategory(
        name="Authentication & Security",
        description="User authentication, password management, 2FA, and security features",
        keywords={'auth', 'login', 'register', 'password', 'token', 'session', '2fa', 'security'},
        priority=1,
        require_auth=False
    ),
    "user": ToolCategory(
        name="User Management",
        description="User profiles, preferences, account settings, and user data",
        keywords={'user', 'profile', 'account', 'settings', 'preference', 'details'},
        priority=2,
        require_auth=True
    ),
    "family": ToolCategory(
        name="Family Management",
        description="Family creation, invitations, members, relationships, and permissions",
        keywords={'family', 'member', 'invite', 'relationship', 'permission'},
        priority=3,
        require_auth=True
    ),
    "workspace": ToolCategory(
        name="Workspace & Productivity",
        description="Workspaces, notes, tasks, projects, folders, files, and collaboration",
        keywords={'workspace', 'note', 'task', 'project', 'folder', 'file', 'collaboration'},
        priority=4,
        require_auth=True
    ),
    "shop": ToolCategory(
        name="Shop & Commerce",
        description="Browse shop, purchase items, themes, avatars, and digital assets",
        keywords={'shop', 'purchase', 'buy', 'cart', 'product', 'theme', 'avatar', 'banner', 'asset'},
        priority=5,
        require_auth=True
    ),
    "finance": ToolCategory(
        name="Financial & Transactions",
        description="SBD balance, transactions, transfers, payments, and financial history",
        keywords={'balance', 'transaction', 'transfer', 'payment', 'sbd', 'wallet', 'finance'},
        priority=6,
        require_auth=True
    ),
    "notifications": ToolCategory(
        name="Notifications & Communication",
        description="Notifications, alerts, messages, email, and communication preferences",
        keywords={'notification', 'alert', 'message', 'email', 'communication', 'notify'},
        priority=7,
        require_auth=True
    ),
    "admin": ToolCategory(
        name="Administration & Moderation",
        description="Admin actions, moderation, audit logs, user management, and system control",
        keywords={'admin', 'ban', 'moderate', 'audit', 'log', 'control', 'manage', 'emergency'},
        priority=8,
        require_auth=True
    ),
    "system": ToolCategory(
        name="System & Utilities",
        description="System health, diagnostics, utilities, testing, and information",
        keywords={'health', 'test', 'echo', 'ping', 'info', 'server', 'system', 'diagnostic', 'utility'},
        priority=9,
        require_auth=False
    ),
}


def categorize_tool(tool_name: str) -> str:
    """
    Determine which category a tool belongs to based on its name.
    
    Args:
        tool_name: Name of the tool
        
    Returns:
        Category key (defaults to 'system' if no match)
    """
    tool_lower = tool_name.lower()
    
    # Check each category's keywords
    for cat_key, category in TOOL_CATEGORIES.items():
        if any(keyword in tool_lower for keyword in category.keywords):
            return cat_key
    
    # Default to system utilities
    return "system"


def get_tools_by_category(tools: Dict[str, any]) -> Dict[str, List[str]]:
    """
    Organize tools into categories.
    
    Args:
        tools: Dictionary of tool names to tool objects
        
    Returns:
        Dictionary mapping category keys to lists of tool names
    """
    categorized = {cat: [] for cat in TOOL_CATEGORIES.keys()}
    
    for tool_name in tools.keys():
        category = categorize_tool(tool_name)
        categorized[category].append(tool_name)
    
    return categorized


def get_category_description(category_key: str) -> str:
    """Get human-readable description for a category."""
    if category_key in TOOL_CATEGORIES:
        cat = TOOL_CATEGORIES[category_key]
        return f"{cat.name}: {cat.description}"
    return "Unknown category"


def get_high_priority_tools(tools: Dict[str, any], user_context: Dict = None) -> List[str]:
    """
    Get list of high-priority tools based on user context.
    
    Args:
        tools: All available tools
        user_context: User context (authenticated, role, etc.)
        
    Returns:
        List of prioritized tool names
    """
    categorized = get_tools_by_category(tools)
    prioritized = []
    
    # Sort categories by priority
    sorted_cats = sorted(
        TOOL_CATEGORIES.items(), 
        key=lambda x: x[1].priority
    )
    
    # Add tools from each category in priority order
    for cat_key, cat_info in sorted_cats:
        # Check auth requirements
        if cat_info.require_auth and user_context and not user_context.get('authenticated'):
            continue
            
        prioritized.extend(categorized.get(cat_key, []))
    
    return prioritized
