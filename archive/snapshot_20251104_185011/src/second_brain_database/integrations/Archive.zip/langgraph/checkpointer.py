"""Redis-based checkpointer for LangGraph state persistence."""
import pickle
from typing import Optional, Dict, Any, Sequence
from datetime import timedelta

from langgraph.checkpoint.base import BaseCheckpointSaver, Checkpoint, CheckpointMetadata
from langchain_core.runnables import RunnableConfig

from ...managers.redis_manager import RedisManager
from ...managers.logging_manager import get_logger

logger = get_logger(prefix="[RedisCheckpointer]")


class RedisCheckpointSaver(BaseCheckpointSaver):
    """Save LangGraph checkpoints to Redis for state persistence.
    
    This allows conversation state to persist across server restarts
    and enables features like:
    - Resume conversations from any point
    - Time-travel debugging
    - Multi-turn conversations with memory
    """
    
    def __init__(
        self,
        redis_manager: RedisManager,
        ttl: int = 86400,  # 24 hours default
        key_prefix: str = "langgraph:checkpoint:"
    ):
        """Initialize the Redis checkpointer.
        
        Args:
            redis_manager: Redis manager instance
            ttl: Time-to-live for checkpoints in seconds
            key_prefix: Prefix for Redis keys
        """
        self.redis = redis_manager.client
        self.ttl = ttl
        self.key_prefix = key_prefix
        self.logger = logger
    
    def _make_key(self, thread_id: str, checkpoint_id: str = None) -> str:
        """Generate Redis key for a checkpoint.
        
        Args:
            thread_id: Thread identifier
            checkpoint_id: Optional specific checkpoint ID
            
        Returns:
            Redis key string
        """
        if checkpoint_id:
            return f"{self.key_prefix}{thread_id}:{checkpoint_id}"
        return f"{self.key_prefix}{thread_id}:latest"
    
    def get(self, config: RunnableConfig) -> Optional[Checkpoint]:
        """Load checkpoint from Redis.
        
        Args:
            config: Runnable configuration with thread_id
            
        Returns:
            Checkpoint if found, None otherwise
        """
        try:
            thread_id = config["configurable"]["thread_id"]
            checkpoint_id = config["configurable"].get("checkpoint_id")
            
            key = self._make_key(thread_id, checkpoint_id)
            data = self.redis.get(key)
            
            if data:
                checkpoint_data = pickle.loads(data)
                self.logger.debug(f"Loaded checkpoint for thread {thread_id}")
                return checkpoint_data.get("checkpoint")
            
            self.logger.debug(f"No checkpoint found for thread {thread_id}")
            return None
            
        except Exception as e:
            self.logger.error(f"Error loading checkpoint: {e}")
            return None
    
    def put(
        self,
        config: RunnableConfig,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata
    ) -> RunnableConfig:
        """Save checkpoint to Redis.
        
        Args:
            config: Runnable configuration
            checkpoint: Checkpoint to save
            metadata: Checkpoint metadata
            
        Returns:
            Updated configuration
        """
        try:
            thread_id = config["configurable"]["thread_id"]
            
            # Save latest checkpoint
            key = self._make_key(thread_id)
            data = pickle.dumps({
                "checkpoint": checkpoint,
                "metadata": metadata,
                "config": config
            })
            
            self.redis.setex(key, self.ttl, data)
            
            # Optionally save versioned checkpoint
            if checkpoint.get("id"):
                versioned_key = self._make_key(thread_id, checkpoint["id"])
                self.redis.setex(versioned_key, self.ttl, data)
            
            self.logger.debug(f"Saved checkpoint for thread {thread_id}")
            return config
            
        except Exception as e:
            self.logger.error(f"Error saving checkpoint: {e}")
            raise
    
    def list(self, config: RunnableConfig) -> Sequence[Checkpoint]:
        """List all checkpoints for a thread.
        
        Args:
            config: Runnable configuration with thread_id
            
        Returns:
            List of checkpoints
        """
        try:
            thread_id = config["configurable"]["thread_id"]
            pattern = f"{self.key_prefix}{thread_id}:*"
            
            checkpoints = []
            for key in self.redis.scan_iter(match=pattern):
                data = self.redis.get(key)
                if data:
                    checkpoint_data = pickle.loads(data)
                    checkpoints.append(checkpoint_data.get("checkpoint"))
            
            self.logger.debug(f"Listed {len(checkpoints)} checkpoints for thread {thread_id}")
            return checkpoints
            
        except Exception as e:
            self.logger.error(f"Error listing checkpoints: {e}")
            return []
    
    def delete(self, config: RunnableConfig) -> None:
        """Delete all checkpoints for a thread.
        
        Args:
            config: Runnable configuration with thread_id
        """
        try:
            thread_id = config["configurable"]["thread_id"]
            pattern = f"{self.key_prefix}{thread_id}:*"
            
            # Delete all matching keys
            deleted = 0
            for key in self.redis.scan_iter(match=pattern):
                self.redis.delete(key)
                deleted += 1
            
            self.logger.info(f"Deleted {deleted} checkpoints for thread {thread_id}")
            
        except Exception as e:
            self.logger.error(f"Error deleting checkpoints: {e}")
            raise


def get_checkpointer(redis_manager: RedisManager, ttl: int = None) -> RedisCheckpointSaver:
    """Factory function to create a Redis checkpointer.
    
    Args:
        redis_manager: Redis manager instance
        ttl: Optional TTL override
        
    Returns:
        RedisCheckpointSaver instance
    """
    from ...config import settings
    
    if ttl is None:
        ttl = settings.LANGCHAIN_MEMORY_TTL
    
    return RedisCheckpointSaver(
        redis_manager=redis_manager,
        ttl=ttl
    )
