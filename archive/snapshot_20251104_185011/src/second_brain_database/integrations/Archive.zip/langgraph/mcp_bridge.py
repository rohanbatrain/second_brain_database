"""
MCP to LangChain Tool Bridge

Converts FastMCP tools to LangChain-compatible tools for use in LangGraph.
Directly uses the existing MCP tool registry from the FastMCP server.
"""

from typing import List, Any, Dict, Optional
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field
import sys
import os

# Add project root to path for absolute imports
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from second_brain_database.managers.logging_manager import get_logger

logger = get_logger(prefix="[MCPBridge]")

# Global tool cache to avoid reloading 146 tools on every message
_TOOLS_CACHE = None
_CACHE_LOCK = None


def get_mcp_tools_as_langchain_tools() -> List[Any]:
    """
    Get all MCP tools from the server registry and wrap them as LangChain tools.
    
    Uses caching to avoid reloading tools on every call.
    
    Returns:
        List of LangChain-compatible tools
    """
    global _TOOLS_CACHE, _CACHE_LOCK
    
    # Return cached tools if available
    if _TOOLS_CACHE is not None:
        logger.debug(f"Returning {len(_TOOLS_CACHE)} cached tools")
        return _TOOLS_CACHE
    
    # Thread-safe initialization
    if _CACHE_LOCK is None:
        from threading import Lock
        _CACHE_LOCK = Lock()
    
    with _CACHE_LOCK:
        # Double-check after acquiring lock
        if _TOOLS_CACHE is not None:
            return _TOOLS_CACHE
        
        logger.info("Loading and caching MCP tools from server registry")
    
    tools = []
    
    try:
        # Import the MCP server instance
        from second_brain_database.integrations.mcp.modern_server import mcp
        
        # FastMCP 2.x stores tools in mcp._tool_manager._tools (internal registry)
        # Get all registered tools directly from the tool manager
        if hasattr(mcp, '_tool_manager') and hasattr(mcp._tool_manager, '_tools'):
            mcp_tools = mcp._tool_manager._tools
            logger.info(f"Found {len(mcp_tools)} registered MCP tools in _tool_manager")
            
            for tool_name, tool_def in mcp_tools.items():
                try:
                    # Extract tool metadata from FastMCP tool definition
                    name = getattr(tool_def, 'name', tool_name)
                    description = getattr(tool_def, 'description', f"MCP tool: {tool_name}")
                    
                    # Truncate long descriptions
                    if len(description) > 1024:
                        description = description[:1021] + "..."
                    
                    # Get the actual tool function
                    tool_func = getattr(tool_def, 'fn', None)
                    if not tool_func:
                        logger.debug(f"Skipping {tool_name}: no function found")
                        continue
                    
                    # Create a sync wrapper that handles async MCP tools
                    def make_tool_wrapper(func, tool_name):
                        """Create sync wrapper that handles both sync and async MCP tools"""
                        import asyncio
                        import inspect
                        
                        def wrapper(**kwargs):
                            """Execute MCP tool (handles both sync/async)."""
                            try:
                                # Check if function is async
                                if inspect.iscoroutinefunction(func):
                                    # Run async function in event loop
                                    try:
                                        loop = asyncio.get_event_loop()
                                        if loop.is_running():
                                            # If loop is already running, create a new one
                                            import nest_asyncio
                                            nest_asyncio.apply()
                                    except RuntimeError:
                                        loop = asyncio.new_event_loop()
                                        asyncio.set_event_loop(loop)
                                    
                                    result = loop.run_until_complete(func(**kwargs))
                                else:
                                    # Sync function, call directly
                                    result = func(**kwargs)
                                
                                return str(result) if result is not None else "Success"
                            except Exception as e:
                                logger.error(f"Error executing {tool_name}: {e}")
                                return f"Error: {str(e)}"
                        
                        wrapper.__name__ = tool_name
                        wrapper.__doc__ = func.__doc__ or f"MCP tool: {tool_name}"
                        return wrapper
                    
                    # Create LangChain StructuredTool
                    lc_tool = StructuredTool.from_function(
                        func=make_tool_wrapper(tool_func, name),
                        name=name,
                        description=description,
                        return_direct=False,
                    )
                    
                    tools.append(lc_tool)
                    logger.debug(f"✓ Wrapped {name}")
                    
                except Exception as e:
                    logger.debug(f"Skipping {tool_name}: {e}")
                    continue
            
            logger.info(f"✓ Successfully wrapped {len(tools)} MCP tools as LangChain tools")
            
            # Cache the tools
            _TOOLS_CACHE = tools
            
        else:
            logger.warning("No tools found in MCP server registry (_tool_manager._tools)")
                    
    except Exception as e:
        logger.error(f"Failed to load MCP tools from server: {e}", exc_info=True)
    
    # If no tools found, use fallback
    if not tools:
        logger.warning("No MCP tools found, using fallback tools")
        tools = create_simple_langchain_tools()
        _TOOLS_CACHE = tools
    
    return tools


def create_simple_langchain_tools() -> List[Any]:
    """
    Create simple mock tools for development/testing without MCP server.
    
    Returns:
        List of basic LangChain tools for testing
    """
    from langchain_core.tools import tool
    
    @tool
    def search_shop(query: str) -> str:
        """Search for items in the shop by name or description."""
        return f"Found items matching '{query}': Serenity Green Theme ($250), Playful Eye Avatar ($2500), Pacific Blue Theme ($250)"
    
    @tool
    def check_balance() -> str:
        """Check your current SBD token balance."""
        return "Your balance: 1000 SBD tokens"
    
    @tool
    def my_profile() -> str:
        """Get your user profile information."""
        return "Username: dev_user | Role: developer | Email: dev@example.com | SBD Balance: 1000"
    
    @tool
    def list_families() -> str:
        """List all families you belong to."""
        return "You belong to 1 family: Smith Family (admin)"
    
    @tool
    def browse_shop() -> str:
        """Browse available shop items."""
        return "Available items: Themes (4), Avatars (12), Banners (6), Bundles (3)"
    
    return [search_shop, check_balance, my_profile, list_families, browse_shop]
